const { getMainKeyboard } = require('../utils/keyboard');

/**
 * Handle /start command — style menu lengkap
 */
async function handleStart(bot, msg) {
    const chatId = msg.chat.id;
    const safeName = (msg.from.first_name || 'User').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const botName = process.env.BOT_DISPLAY_NAME || 'ASISTEN ELXZ BUILD';

    const welcomeCaption = `
👋 Halo, <b>${safeName}</b>!
Selamat datang di <b>${botName}</b> ✨

🤖 <b>${botName}</b>
Automated Cloud Compiler & Utility System

⭐ <b>Fitur Unggulan</b>
• 🌐 Web to APK — ubah website jadi APK
• 🚀 Build Project ZIP (Flutter / Android)
• 📋 Antrian build + status server
• Utility project (menu berwarna di bawah)

🟢 Status: Online · Ready to Compile

Pilih menu di bawah untuk mulai 👇
    `.trim();

    const photoUrl = process.env.START_PHOTO_URL || '';

    try {
        if (photoUrl) {
            await bot.sendPhoto(chatId, photoUrl, {
                caption: welcomeCaption,
                parse_mode: 'HTML',
                reply_markup: getMainKeyboard()
            });
        } else {
            await bot.sendMessage(chatId, welcomeCaption, {
                parse_mode: 'HTML',
                reply_markup: getMainKeyboard()
            });
        }
    } catch (e) {
        await bot.sendMessage(chatId, welcomeCaption, {
            parse_mode: 'HTML',
            reply_markup: getMainKeyboard()
        });
    }
}

module.exports = { handleStart };
