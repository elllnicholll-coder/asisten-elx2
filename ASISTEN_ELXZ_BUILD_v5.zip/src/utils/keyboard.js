/**
 * Generate inline keyboards for bot
 * Style menu banyak fitur (disesuaikan SC BUILD APK)
 */

function getMainKeyboard() {
    const ownerUrl = process.env.OWNER_URL || 'https://t.me/elnicholl';
    const channelUrl = process.env.CHANNEL_URL || (
        process.env.REQUIRED_CHANNEL
            ? `https://t.me/${String(process.env.REQUIRED_CHANNEL || '').replace('@', '')}`
            : 'https://t.me/elxzchannel'
    );

    return {
        inline_keyboard: [
            [{ text: '🔗 To URL — Upload Jadi Link', callback_data: 'feat_to_url' }],
            [{ text: '👥 Group Menu', callback_data: 'feat_group' }],
            [{ text: '🤖 Chat AI — Rombak Project', callback_data: 'feat_chat_ai' }],
            [
                { text: '🚀 Mulai Build APK', callback_data: 'build_zip' },
                { text: '🌐 Web to APK', callback_data: 'create_apk' }
            ],
            [{ text: '➕ Add Fitur', callback_data: 'feat_add_fitur' }],
            [
                { text: '🔧 Ganti Function', callback_data: 'feat_ganti_function' },
                { text: '📄 Ganti File .dart', callback_data: 'feat_ganti_dart' }
            ],
            [
                { text: '🧪 Tes Function', callback_data: 'feat_tes_function' },
                { text: '🛠️ Fix Error Function', callback_data: 'feat_fix_error' }
            ],
            [
                { text: '🎨 Recolour Project', callback_data: 'feat_recolour' },
                { text: '🌈 Multi Recolour', callback_data: 'feat_multi_recolour' }
            ],
            [{ text: '✏️ Rename All (Domain/Nama Apk/Aset)', callback_data: 'feat_rename_all' }],
            [{ text: '🆔 Rename Package ID (Android)', callback_data: 'feat_rename_package' }],
            [
                { text: '📁 Ganti Aset', callback_data: 'feat_ganti_aset' },
                { text: '✏️ Rename Nama Apk', callback_data: 'feat_rename_apk' }
            ],
            [
                { text: '📜 Rename Api/Script', callback_data: 'feat_rename_api' },
                { text: '📦 Get Aset', callback_data: 'feat_get_aset' }
            ],
            [
                { text: '💻 HTML → JS / Deploy', callback_data: 'feat_html_js' },
                { text: '👁️ Preview Dart', callback_data: 'feat_preview_dart' }
            ],
            [{ text: '🔒 Enc Menu — Script/HTML', callback_data: 'feat_enc' }],
            [
                { text: '🔍 Cari di Project', callback_data: 'feat_cari' },
                { text: '📊 Scan Info Project', callback_data: 'feat_scan_info' }
            ],
            [{ text: '🧹 Bersihkan Zip (Junk/Build)', callback_data: 'feat_bersih_zip' }],
            [
                { text: '📋 Antrian Build', callback_data: 'check_queue' },
                { text: '📈 Status Server', callback_data: 'server_status' }
            ],
            [
                { text: '📜 Menu Perintah', callback_data: 'show_commands' },
                { text: '❓ Bantuan', callback_data: 'help' }
            ],
            [
                { text: '👤 Owner ↗', url: ownerUrl },
                { text: '📢 Channel ↗', url: channelUrl.startsWith('http') ? channelUrl : 'https://t.me/yourchannel' }
            ]
        ]
    };
}

function getColorKeyboard() {
    return {
        inline_keyboard: [
            [{ text: '🔵 Biru', callback_data: 'color_blue' }, { text: '🔴 Merah', callback_data: 'color_red' }, { text: '🟢 Hijau', callback_data: 'color_green' }],
            [{ text: '🟣 Ungu', callback_data: 'color_purple' }, { text: '🟠 Oranye', callback_data: 'color_orange' }, { text: '🔵 Teal', callback_data: 'color_teal' }],
            [{ text: '💗 Pink', callback_data: 'color_pink' }, { text: '🔵 Indigo', callback_data: 'color_indigo' }],
            [{ text: '❌ Batal', callback_data: 'cancel' }]
        ]
    };
}

function getConfirmKeyboard() {
    return {
        inline_keyboard: [
            [{ text: '✅ Buat APK', callback_data: 'confirm_build' }],
            [{ text: '❌ Batal', callback_data: 'cancel' }]
        ]
    };
}

function getCancelKeyboard() {
    return {
        inline_keyboard: [
            [{ text: '❌ Batal', callback_data: 'cancel' }]
        ]
    };
}

function getIconKeyboard() {
    return {
        inline_keyboard: [
            [{ text: '⏭️ Lewati (Gunakan Default)', callback_data: 'skip_icon' }],
            [{ text: '❌ Batal', callback_data: 'cancel' }]
        ]
    };
}

function getZipTypeKeyboard() {
    return {
        inline_keyboard: [
            [{ text: '🤖 Android Studio / Gradle', callback_data: 'zip_android' }, { text: '💙 Flutter Project', callback_data: 'zip_flutter' }],
            [{ text: '❌ Batal', callback_data: 'cancel' }]
        ]
    };
}

function getZipBuildTypeKeyboard() {
    return {
        inline_keyboard: [
            [{ text: '🐛 Debug APK (Fast)', callback_data: 'zipbuild_debug' }, { text: '🚀 Release APK', callback_data: 'zipbuild_release' }],
            [{ text: '❌ Batal', callback_data: 'cancel' }]
        ]
    };
}

module.exports = {
    getMainKeyboard,
    getColorKeyboard,
    getConfirmKeyboard,
    getCancelKeyboard,
    getIconKeyboard,
    getZipTypeKeyboard,
    getZipBuildTypeKeyboard
};
