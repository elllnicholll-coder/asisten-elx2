/**
 * Admin Reporter + LIVE BUILD MONITOR (log channel)
 */

function escapeHtml(text) {
    if (!text) return '';
    return String(text)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

function mauBuildKeyboard() {
    return {
        inline_keyboard: [
            [{ text: '🚀 Mau Build Juga?, Gas!', callback_data: 'build_zip' }]
        ]
    };
}

/**
 * Kirim log ke channel LOG_CHANNEL (LIVE BUILD MONITOR)
 */
async function sendLogChannel(bot, status, data = {}) {
    const logId = process.env.LOG_CHANNEL;
    if (!logId) return;

    const title = process.env.LOG_TITLE || 'LIVE BUILD MONITOR';
    const userId = data.id || data.userId || '-';
    const name = escapeHtml(data.name || data.fullName || 'Unknown');
    const username = data.username ? '@' + escapeHtml(data.username) : '';
    const developer = username ? `${name} (${username})` : name;
    const project = escapeHtml(data.appName || data.project || 'project');
    const mode = escapeHtml(data.buildMode || data.mode || 'Release');
    const typeLabel = escapeHtml(data.typeLabel || data.type || 'APK');
    const detail = escapeHtml(data.detail || '');
    const sizeMB = data.sizeMB || '';

    let progres = 'STATUS → STARTED';
    let emoji = '🟡';
    if (status === 'success') {
        progres = 'STATUS → COMPLETED';
        emoji = '🟢';
    } else if (status === 'failed') {
        progres = 'STATUS → ERROR';
        emoji = '🔴';
    } else if (status === 'progress') {
        progres = 'STATUS → BUILDING';
        emoji = '🔵';
    }

    const text = `
📦 <b>${escapeHtml(title)}</b> 📦
━━━━━━━━━━━━━━━━━━━━

👤 <b>Developer</b> : ${developer}
🆔 <b>User ID</b> : <code>${userId}</code>
📦 <b>Project</b> : <code>${project}</code>
🔧 <b>Mode</b> : 🚀 ${mode}
🏷 <b>Type</b> : ${typeLabel}

📊 <b>PROGRES AKTIF:</b>
${progres}
DETAIL → ${detail || (status === 'success' ? `Build sukses${sizeMB ? ' • ' + sizeMB + ' MB' : ''}. APK dikirim ke user.` : status === 'failed' ? 'Build gagal.' : 'Memulai proses build...')}

━━━━━━━━━━━━━━━━━━━━
🤖 Multi-build Server Active — Proses berjalan independen.
    `.trim();

    try {
        await bot.sendMessage(logId, text, {
            parse_mode: 'HTML',
            reply_markup: mauBuildKeyboard(),
            disable_web_page_preview: true
        });
    } catch (e) {
        console.error('[LOG CHANNEL] Gagal kirim:', e.message);
    }
}

async function sendBuildReport(bot, userData, appData) {
    const ownerId = process.env.ADMIN_IDS?.split(',')[0];
    const timestamp = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });

    const safeName = escapeHtml(userData.name) || 'Unknown';
    const safeUsername = userData.username ? '@' + escapeHtml(userData.username) : '-';
    const safeAppName = escapeHtml(appData.appName) || 'N/A';
    const safeUrl = escapeHtml(appData.url) || 'N/A';
    const safeColor = escapeHtml(appData.themeColor) || '#2196F3';

    // LIVE BUILD MONITOR ke channel
    await sendLogChannel(bot, 'success', {
        id: userData.id,
        name: userData.name,
        username: userData.username,
        appName: appData.appName || appData.projectFile || 'project',
        buildMode: appData.buildMode || 'Release',
        typeLabel: appData.typeLabel || (appData.url ? 'WebView' : 'Flutter/Android'),
        sizeMB: appData.sizeMB || '',
        detail: `Proses kompilasi sukses. APK dikirim ke user.`
    });

    if (!ownerId) return;

    const reportMsg = `
🔔 <b>BUILD REPORT</b>
━━━━━━━━━━━━━━━━━━
👤 <b>User:</b>
• ID: <code>${userData.id}</code>
• Name: ${safeName}
• Username: ${safeUsername}

📱 <b>Application:</b>
• Name: <b>${safeAppName}</b>
• URL: <code>${safeUrl}</code>
• Color: ${safeColor}

⏱ <b>Time:</b> ${timestamp}
━━━━━━━━━━━━━━━━━━
✅ <i>Build Completed Successfully</i>
    `.trim();

    try {
        await bot.sendMessage(ownerId, reportMsg, {
            parse_mode: 'HTML',
            disable_web_page_preview: true,
            reply_markup: mauBuildKeyboard()
        });
    } catch (e) {
        console.error('Failed to send admin report:', e.message);
    }
}

async function sendBuildFailedLog(bot, userData, appData, errorMsg) {
    await sendLogChannel(bot, 'failed', {
        id: userData.id || userData.userId,
        name: userData.name,
        username: userData.username,
        appName: appData?.appName || 'project',
        buildMode: appData?.buildMode || 'Release',
        typeLabel: appData?.typeLabel || 'APK',
        detail: String(errorMsg || 'Unknown error').slice(0, 180)
    });
}

module.exports = { sendBuildReport, sendLogChannel, sendBuildFailedLog };
