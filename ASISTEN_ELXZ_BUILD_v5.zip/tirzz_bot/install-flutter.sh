#!/bin/bash
# Install Flutter di VPS supaya build lokal jalan (lebih cepat & andal)
set -e
echo "=== Install Flutter + dependencies ==="
apt-get update -qq
apt-get install -y -qq curl git unzip xz-utils zip libglu1-mesa openjdk-17-jdk clang cmake ninja-build pkg-config libgtk-3-dev

if [ ! -d /opt/flutter ]; then
  git clone https://github.com/flutter/flutter.git -b stable --depth 1 /opt/flutter
fi
export PATH="/opt/flutter/bin:$PATH"
echo 'export PATH="/opt/flutter/bin:$PATH"' >> /root/.bashrc

flutter precache
flutter doctor -v || true
flutter config --no-analytics
echo "=== Selesai. Jalankan: flutter --version ==="
