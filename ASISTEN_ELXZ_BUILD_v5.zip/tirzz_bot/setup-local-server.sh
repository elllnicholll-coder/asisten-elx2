#!/bin/bash
# ============================================================
#  ASISTEN ELXZ BUILD — Setup Telegram Local Bot API Server
#  Menghilangkan batas 20MB pada getFile, support file hingga 2GB
#  Jalankan sekali di VPS/server kamu: bash setup-local-server.sh
# ============================================================

set -e

# Isi dari config.js / my.telegram.org
BOT_TOKEN="YOUR_BOT_TOKEN_HERE"
# API ID & HASH dari https://my.telegram.org → API development tools
TELEGRAM_API_ID="YOUR_API_ID"
TELEGRAM_API_HASH="YOUR_API_HASH"

LOCAL_PORT=8081
FILES_DIR="/var/lib/telegram-bot-api"
LOG_FILE="/var/log/telegram-bot-api.log"

if [ "$TELEGRAM_API_ID" = "YOUR_API_ID" ] || [ -z "$TELEGRAM_API_ID" ]; then
  echo "[ERROR] Isi TELEGRAM_API_ID dan TELEGRAM_API_HASH di file setup-local-server.sh"
  echo "        Dapatkan di https://my.telegram.org"
  exit 1
fi

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║   ASISTEN ELXZ BUILD - Setup Telegram Local Bot API      ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

# ── 1. Cek OS ───────────────────────────────────────────────
if [ -f /etc/debian_version ]; then
    PKG="apt-get"
    echo "[INFO] Terdeteksi: Debian/Ubuntu"
elif [ -f /etc/redhat-release ]; then
    PKG="yum"
    echo "[INFO] Terdeteksi: CentOS/RHEL"
else
    echo "[WARN] OS tidak dikenal, coba lanjutkan..."
    PKG="apt-get"
fi

# ── 2. Install dependencies ─────────────────────────────────
echo ""
echo "[STEP 1] Install dependencies..."
if [ "$PKG" = "apt-get" ]; then
    apt-get update -qq
    apt-get install -y -qq \
        cmake g++ git zlib1g-dev libssl-dev gperf \
        make curl wget unzip
else
    yum install -y cmake gcc-c++ git zlib-devel openssl-devel \
        gperf make curl wget unzip
fi

# ── 3. Clone & build telegram-bot-api ───────────────────────
echo ""
echo "[STEP 2] Clone telegram-bot-api..."
cd /tmp
if [ -d telegram-bot-api ]; then
    echo "[INFO] Direktori sudah ada, update..."
    cd telegram-bot-api
    git pull
else
    git clone --recursive https://github.com/tdlib/telegram-bot-api.git
    cd telegram-bot-api
fi

echo ""
echo "[STEP 3] Build telegram-bot-api (ini butuh 5-15 menit)..."
rm -rf build
mkdir -p build
cd build
cmake -DCMAKE_BUILD_TYPE=Release ..
cmake --build . --target telegram-bot-api -j$(nproc)

# ── 4. Install binary ───────────────────────────────────────
echo ""
echo "[STEP 4] Install binary..."
cp telegram-bot-api /usr/local/bin/telegram-bot-api
chmod +x /usr/local/bin/telegram-bot-api
echo "[OK] Binary: $(which telegram-bot-api)"

# ── 5. Buat direktori files ─────────────────────────────────
echo ""
echo "[STEP 5] Buat direktori penyimpanan file..."
mkdir -p "$FILES_DIR"
chmod 777 "$FILES_DIR"

# ── 6. Buat systemd service ─────────────────────────────────
echo ""
echo "[STEP 6] Buat systemd service..."
cat > /etc/systemd/system/telegram-bot-api.service << SERVICEEOF
[Unit]
Description=Telegram Bot API Local Server (ELXZ)
After=network.target

[Service]
Type=simple
User=root
ExecStart=/usr/local/bin/telegram-bot-api --api-id=${TELEGRAM_API_ID} --api-hash=${TELEGRAM_API_HASH} --local --dir=${FILES_DIR} --http-port=${LOCAL_PORT} --max-webhook-connections=100
Restart=always
RestartSec=5
StandardOutput=append:${LOG_FILE}
StandardError=append:${LOG_FILE}

[Install]
WantedBy=multi-user.target
SERVICEEOF

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║         ⚠️  LANGKAH WAJIB (MANUAL)          ║"
echo "╚══════════════════════════════════════════════╝"
echo ""
echo "Sebelum menjalankan service, kamu perlu:"
echo ""
echo "1. Daftarkan App di https://my.telegram.org/apps"
echo "   → Dapatkan API_ID dan API_HASH"
echo ""
echo "2. Set environment variable:"
echo "   export TELEGRAM_API_ID=<api_id_kamu>"
echo "   export TELEGRAM_API_HASH=<api_hash_kamu>"
echo ""
echo "   Atau edit /etc/systemd/system/telegram-bot-api.service"
echo "   dan ganti \${TELEGRAM_API_ID} & \${TELEGRAM_API_HASH}"
echo "   dengan nilai aslinya."
echo ""
echo "3. Aktifkan dan jalankan service:"
echo "   systemctl daemon-reload"
echo "   systemctl enable telegram-bot-api"
echo "   systemctl start telegram-bot-api"
echo ""
echo "4. Cek status:"
echo "   systemctl status telegram-bot-api"
echo "   tail -f ${LOG_FILE}"
echo ""
echo "5. Test local server berjalan:"
echo "   curl http://localhost:${LOCAL_PORT}/bot${BOT_TOKEN}/getMe"
echo ""
echo "6. Setelah server jalan, restart bot:"
echo "   pm2 restart all   (atau node index.js)"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Local server akan berjalan di:"
echo "  http://localhost:${LOCAL_PORT}"
echo ""
echo "  File ZIP/APK disimpan di: ${FILES_DIR}"
echo "  Log: ${LOG_FILE}"
echo ""
echo "  Config di config.js sudah diset:"
echo "  localServer.enabled = true"
echo "  localServer.host = http://localhost:${LOCAL_PORT}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
