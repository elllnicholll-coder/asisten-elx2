const { Bot, InlineKeyboard, InputFile } = require('grammy');
const express = require('express');
const session = require('express-session');
const fs = require('fs');
const fsp = require('fs').promises;
const path = require('path');
const axios = require('axios');
const chalk = require('chalk');
const FormData = require('form-data');
const config = require('./config.js');

// ==================== IMAGE HELPER (folder images/) ====================
function getImagePath(key) {
    try {
        const folder = (config.images && config.images.folder) ? config.images.folder : './images';
        let filename = null;
        if (key === 'monitorlog') filename = (config.images && config.images.monitorlog) || 'monitorlog.jpg';
        else if (key === 'botlogo') filename = (config.images && config.images.botlogo) || 'botlogo.jpg';
        else filename = (config.images && config.images.botlogo) || 'botlogo.jpg';
        const full = path.join(__dirname, folder, filename);
        if (fs.existsSync(full)) return full;
    } catch (_) {}
    return null;
}


// ==================== SEND LARGE FILE (UP TO 500MB via multipart) ====================
// Jika localServer aktif: getFile tidak ada batas ukuran (2GB), download langsung dari disk
// Jika localServer tidak aktif: getFile dibatasi 20MB, pakai forward file_id untuk file besar
// Support file ZIP hingga 500MB (2GB jika pakai local server)

// ==================== HELPER: BANGUN URL API ====================
// Jika local server aktif, semua panggilan API dan file pakai host lokal
const LOCAL_API   = config.localServer?.enabled ? config.localServer.host : 'https://api.telegram.org';
const BOT_TOKEN   = config.bot.token;

function apiUrl(method) {
    return `${LOCAL_API}/bot${BOT_TOKEN}/${method}`;
}
function fileUrl(filePath) {
    // Local server: http://localhost:8081/file/bot<TOKEN>/<path>
    // Cloud server: https://api.telegram.org/file/bot<TOKEN>/<path>
    return `${LOCAL_API}/file/bot${BOT_TOKEN}/${filePath}`;
}

// ==================== HELPER: DOWNLOAD FILE BY FILE_ID ====================
async function downloadFileByFileId(fileId, destPath) {
    // getFile: tidak ada batas ukuran jika pakai local server
    const fileInfo = await bot.api.getFile(fileId);
    if (!fileInfo.file_path) throw new Error('file_path tidak tersedia dari getFile');

    // Jika local server aktif DAN file ada di disk lokal — copy langsung (sangat cepat)
    if (config.localServer?.enabled && config.localServer.filesDir) {
        const localPath = path.join(config.localServer.filesDir, fileInfo.file_path);
        if (fs.existsSync(localPath)) {
            console.log(`[DOWNLOAD] Copy langsung dari disk lokal: ${localPath}`);
            await fsp.copyFile(localPath, destPath);
            return { ok: true, method: 'local-copy' };
        }
    }

    // Fallback: download via HTTP stream (local server atau cloud)
    const url = fileUrl(fileInfo.file_path);
    console.log(`[DOWNLOAD] HTTP stream dari: ${url}`);
    const writer = fs.createWriteStream(destPath);
    const dlRes = await axios({
        method: 'GET', url,
        responseType: 'stream',
        timeout: 1800000,
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
    });
    await new Promise((resolve, reject) => {
        dlRes.data.pipe(writer);
        writer.on('finish', resolve);
        writer.on('error', reject);
        dlRes.data.on('error', reject);
    });
    return { ok: true, method: 'http-stream' };
}

async function uploadDocumentMultipart(chatId, filePath, fileName, caption, replyMarkup) {
    const stats = fs.statSync(filePath);
    const sizeMB = (stats.size / 1024 / 1024).toFixed(2);
    console.log(`[UPLOAD] Mengupload ${fileName} (${sizeMB} MB) ke Telegram via ${LOCAL_API}...`);

    const form = new FormData();
    form.append('chat_id', chatId.toString());
    form.append('caption', caption);
    form.append('parse_mode', 'HTML');
    if (replyMarkup) form.append('reply_markup', JSON.stringify(replyMarkup));
    form.append('document', fs.createReadStream(filePath), {
        filename: fileName,
        contentType: 'application/octet-stream',
        knownLength: stats.size
    });

    const uploadRes = await axios.post(
        apiUrl('sendDocument'),
        form,
        {
            headers: form.getHeaders(),
            timeout: 1800000, // 30 menit upload
            maxContentLength: Infinity,
            maxBodyLength: Infinity,
        }
    );

    if (!uploadRes.data.ok) throw new Error('Upload response not ok: ' + JSON.stringify(uploadRes.data));
    console.log(`[UPLOAD] ✅ Upload sukses: ${fileName} (${sizeMB} MB)`);
    return { ok: true, sizeMB };
}

async function sendLargeDocument(chatId, fileIdOrUrl, fileName, caption, replyMarkup, isFileId = false) {
    const TEMP_DIR = path.join(__dirname, 'temp_apk');
    if (!fs.existsSync(TEMP_DIR)) fs.mkdirSync(TEMP_DIR, { recursive: true });

    const tempPath = path.join(TEMP_DIR, `${Date.now()}_${fileName}`);
    let downloaded = false;

    try {
        if (isFileId) {
            // Download via file_id — local server: tidak ada batas ukuran
            console.log(`[UPLOAD] Download via file_id: ${fileIdOrUrl}`);
            await downloadFileByFileId(fileIdOrUrl, tempPath);
        } else {
            // Download via URL (HTTP stream)
            console.log(`[UPLOAD] Download via URL ke disk: ${tempPath}`);
            const writer = fs.createWriteStream(tempPath);
            const dlRes = await axios({
                method: 'GET', url: fileIdOrUrl,
                responseType: 'stream',
                timeout: 1800000,
                maxContentLength: Infinity,
                maxBodyLength: Infinity,
            });
            await new Promise((resolve, reject) => {
                dlRes.data.pipe(writer);
                writer.on('finish', resolve);
                writer.on('error', reject);
                dlRes.data.on('error', reject);
            });
        }
        downloaded = true;
        const result = await uploadDocumentMultipart(chatId, tempPath, fileName, caption, replyMarkup);
        return result;

    } catch (err) {
        console.error('[UPLOAD] ❌ Error:', err.message);
        throw err;
    } finally {
        if (downloaded && fs.existsSync(tempPath)) {
            try { fs.unlinkSync(tempPath); } catch(_) {}
        }
    }
}

// ==================== BOT INIT (LOCAL SERVER AWARE) ====================
// ==================== BOT INIT (AUTO-DETECT LOCAL SERVER) ====================
let bot;
async function initBot() {
    if (config.localServer?.enabled) {
        // Cek apakah local server benar-benar bisa diakses sebelum digunakan
        try {
            const testRes = await axios.get(
                `${config.localServer.host}/bot${config.bot.token}/getMe`,
                { timeout: 3000 }
            );
            if (testRes.data?.ok) {
                console.log(`[BOT] ✅ Local Bot API Server aktif: ${config.localServer.host}`);
                bot = new Bot(config.bot.token, {
                    client: { apiRoot: config.localServer.host }
                });
                return;
            }
        } catch (_) {
            console.warn(`[BOT] ⚠️  Local server tidak bisa diakses di ${config.localServer.host}`);
            console.warn('[BOT] → Fallback ke Telegram cloud API');
        }
    }
    console.log('[BOT] Menggunakan Telegram cloud API');
    bot = new Bot(config.bot.token);
}
// Bot diinisialisasi synchronous dulu (grammY butuh ini), lalu di-start async
// Untuk Pterodactyl: localServer.enabled = false → langsung pakai cloud
if (config.localServer?.enabled) {
    // Akan di-override oleh initBot() jika local server tidak ada
    bot = new Bot(config.bot.token, {
        client: { apiRoot: config.localServer.host }
    });
} else {
    bot = new Bot(config.bot.token);
}
const app = express();

// ==================== DATABASE ====================
const DB_FILE = './db.json';
let db = {
    users: {},
    queue: [],
    building: [],
    stats: { success: 0, failed: 0 },
    webUsers: {},
    roles: {
        developer: [], // Role 1 - Tertinggi (bisa add semua role)
        owner: [],     // Role 2
        pt: [],        // Role 4
        tk: [],        // Role 3
        ress: []       // Role 5
    }
};

if (fs.existsSync(DB_FILE)) {
    try { db = JSON.parse(fs.readFileSync(DB_FILE)); }
    catch (e) { db = { users: {}, queue: [], building: [], stats: { success: 0, failed: 0 }, webUsers: {}, roles: { developer: [], owner: [], pt: [], tk: [], ress: [] } }; }
}
if (!db.webUsers) db.webUsers = {};
if (!db.stats) db.stats = { success: 0, failed: 0 };
if (!db.roles) db.roles = { developer: [], owner: [], pt: [], tk: [], ress: [] };
if (!db.roles.developer) db.roles.developer = [];
if (!db.roles.owner) db.roles.owner = [];
if (!db.roles.pt) db.roles.pt = [];
if (!db.roles.tk) db.roles.tk = [];
if (!db.roles.ress) db.roles.ress = [];

function saveDB() {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}

// ==================== ROLE SYSTEM ====================
/*
  HIERARKI ROLE:
  1. 💎 DEVELOPER  - Tertinggi, bisa add/remove semua role
  2. 👑 OWNER      - Bisa add TK, RESS, PT
  3. 🔰 TK         - Role 3
  4. 🏢 PT         - Role 4
  5. 🎯 RESS       - Role 5
  0. (root)        - config.bot.adminId (developer utama)
*/

const ROLE_INFO = {
    developer: { emoji: '💎', label: 'DEVELOPER', level: 1 },
    owner:     { emoji: '👑', label: 'OWNER',     level: 2 },
    tk:        { emoji: '🔰', label: 'TK',        level: 3 },
    pt:        { emoji: '🏢', label: 'PT',        level: 4 },
    ress:      { emoji: '🎯', label: 'RESS',      level: 5 }
};

function getUserRole(uid) {
    const id = uid.toString();
    if (id === config.bot.adminId) return 'developer'; // root selalu developer
    if (db.roles.developer.includes(id)) return 'developer';
    if (db.roles.owner.includes(id))     return 'owner';
    if (db.roles.tk.includes(id))        return 'tk';
    if (db.roles.pt.includes(id))        return 'pt';
    if (db.roles.ress.includes(id))      return 'ress';
    return null;
}

function getRoleLevel(uid) {
    const role = getUserRole(uid);
    if (!role) return 99;
    return ROLE_INFO[role]?.level ?? 99;
}

function isDeveloper(uid) {
    return getUserRole(uid) === 'developer';
}

function isOwnerOrAbove(uid) {
    const lvl = getRoleLevel(uid);
    return lvl <= 2;
}

function isTkOrAbove(uid) {
    return getRoleLevel(uid) <= 3;
}

function canAddRole(adderUid, targetRole) {
    const adderRole = getUserRole(adderUid);
    if (!adderRole) return false;
    const adderLevel = ROLE_INFO[adderRole]?.level ?? 99;
    const targetLevel = ROLE_INFO[targetRole]?.level ?? 99;
    // Developer bisa add semua role
    // Owner bisa add TK(3), PT(4), RESS(5)
    // TK ke bawah tidak bisa add siapapun
    if (adderLevel === 1) return true;
    if (adderLevel === 2) return targetLevel >= 3;
    return false;
}

function canRemoveRole(removerUid, targetUid) {
    const removerLevel = getRoleLevel(removerUid);
    const targetLevel = getRoleLevel(targetUid);
    if (removerLevel === 1) return true; // Developer bisa remove semua
    if (removerLevel === 2 && targetLevel >= 3) return true; // Owner bisa remove TK/PT/RESS
    return false;
}

function addRole(targetId, role) {
    const id = targetId.toString();
    // Hapus dari role lain dulu
    for (const r of Object.keys(db.roles)) {
        db.roles[r] = db.roles[r].filter(x => x !== id);
    }
    db.roles[role].push(id);
    saveDB();
}

function removeRole(targetId) {
    const id = targetId.toString();
    for (const r of Object.keys(db.roles)) {
        db.roles[r] = db.roles[r].filter(x => x !== id);
    }
    saveDB();
}

function getRoleBadge(uid) {
    const role = getUserRole(uid);
    if (!role) return '';
    return `${ROLE_INFO[role].emoji} [${ROLE_INFO[role].label}]`;
}

function isAdmin(uid) {
    // backward compat: admin = developer level
    return isDeveloper(uid);
}

// ==================== CREDIT SYSTEM ====================
function getUser(uid) {
    if (!db.users[uid]) {
        db.users[uid] = {
            id: uid,
            credit: config.credit.freePerWeek,
            totalReceived: config.credit.freePerWeek,
            totalUsed: 0,
            lastWeekReset: Date.now(),
            joinedChannel: false,
            step: null
        };
        saveDB();
    }
    // Migrate user lama
    if (db.users[uid].totalReceived === undefined) db.users[uid].totalReceived = db.users[uid].credit || 0;
    if (db.users[uid].totalUsed === undefined) db.users[uid].totalUsed = 0;
    return db.users[uid];
}

function checkAndResetWeeklyCredit(uid) {
    const u = getUser(uid);
    const oneWeek = 7 * 24 * 60 * 60 * 1000;
    if (Date.now() - (u.lastWeekReset || 0) >= oneWeek) {
        u.credit = config.credit.freePerWeek;
        u.totalReceived = (u.totalReceived || 0) + config.credit.freePerWeek;
        u.lastWeekReset = Date.now();
        saveDB();
    }
}

function getTopupDaysLeft(uid) {
    const u = getUser(uid);
    const oneWeek = 7 * 24 * 60 * 60 * 1000;
    const elapsed = Date.now() - (u.lastWeekReset || 0);
    const remaining = oneWeek - elapsed;
    if (remaining <= 0) return 0;
    return Math.ceil(remaining / (24 * 60 * 60 * 1000));
}

function getCreditInfoText(uid) {
    const u = getUser(uid);
    const credit = getCredit(uid);
    const daysLeft = getTopupDaysLeft(uid);
    const totalUsed = u.totalUsed || 0;
    const totalReceived = u.totalReceived || credit;
    return (
        `❌ <b>CREDIT TIDAK CUKUP!</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
        `🎟 <b>INFO CREDIT</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
        `🎟 <b>Sisa Credit:</b> ${credit}\n` +
        `✅ <b>Total Digunakan:</b> ${totalUsed}\n` +
        `✅ <b>Total Diterima:</b> ${totalReceived}\n` +
        `⏰ <b>Topup Gratis:</b> ${daysLeft} hari lagi\n` +
        `📦 <i>Setiap build menggunakan ${config.credit.costPerBuild} credit</i>\n` +
        `📡 <i>Broadcast menggunakan 5 credit</i>\n` +
        `🎉 <i>Dapatkan ${config.credit.freePerWeek} credit gratis setiap minggu!</i>\n\n` +
        `🚨 <i>Setiap build membutuhkan ${config.credit.costPerBuild} credit</i>\n` +
        `🚨 <i>Dapatkan ${config.credit.freePerWeek} credit gratis setiap minggu!</i>\n\n` +
        `👤 Hubungi ${config.contact.owner} untuk topup.`
    );
}

function getCredit(uid) {
    checkAndResetWeeklyCredit(uid);
    return db.users[uid].credit || 0;
}

function useCredit(uid) {
    checkAndResetWeeklyCredit(uid);
    const u = db.users[uid];
    if (u.credit < config.credit.costPerBuild) return false;
    u.credit -= config.credit.costPerBuild;
    u.totalUsed = (u.totalUsed || 0) + config.credit.costPerBuild;
    saveDB();
    return true;
}

function addCredit(uid, amount) {
    const u = getUser(uid);
    u.credit = (u.credit || 0) + amount;
    u.totalReceived = (u.totalReceived || 0) + amount;
    saveDB();
}

// ==================== CEK JOIN CHANNEL ====================
async function isUserJoinedChannel(uid) {
    if (uid.toString() === config.bot.adminId) return true;
    if (getUserRole(uid)) return true;
    if (!config.verification?.enabled) return true; // verifikasi dimatikan

    const channelToCheck = config.verification.channelId;
    try {
        const member = await bot.api.getChatMember(channelToCheck, uid);
        const joined = ['member', 'administrator', 'creator'].includes(member.status);
        if (joined) {
            // Simpan status join ke db agar fallback bekerja
            const u = getUser(uid);
            u.joinedChannel = true;
            saveDB();
        }
        return joined;
    } catch (e) {
        console.log('[JOIN] getChatMember error:', e.message);
        // Jika API gagal (misal bot bukan admin channel, atau channel private),
        // JANGAN blokir user — pakai data db terakhir atau izinkan masuk
        const savedStatus = db.users[uid]?.joinedChannel;
        if (savedStatus !== undefined) return savedStatus;
        // Jika tidak ada data sama sekali, izinkan masuk (jangan blokir karena error API)
        console.log('[JOIN] Tidak ada data db, izinkan user masuk (API error)');
        return true;
    }
}

async function checkJoin(ctx) {
    const uid = ctx.from.id;
    if (uid.toString() === config.bot.adminId) return true;
    if (getUserRole(uid)) return true; // Role apapun bypass
    const joined = await isUserJoinedChannel(uid);
    if (!joined) {
        await sendMustJoinMessage(ctx);
        return false;
    }
    const u = getUser(uid);
    u.joinedChannel = true;
    saveDB();
    return true;
}

async function sendMustJoinMessage(ctx) {
    const kb = new InlineKeyboard()
        .url('🔵 📢 JOIN CHANNEL SEKARANG', config.verification.channelUrl)
        .row()
        .text('🟢 ✅ Sudah Join, Cek Lagi', 'check_join');

    const bannerPath = path.join(__dirname, 'banner.mp4');
    const caption =
        `⛔ <b>AKSES DITOLAK!</b>\n\n` +
        `Untuk menggunakan <b>${config.branding.name}</b>,\n` +
        `kamu WAJIB join channel kami terlebih dahulu!\n\n` +
        `📢 Channel: @${config.verification.channelUsername}\n\n` +
        `1️⃣ Klik tombol <b>JOIN CHANNEL</b> di bawah\n` +
        `2️⃣ Setelah join, klik <b>Sudah Join, Cek Lagi</b>\n` +
        `3️⃣ Bot siap digunakan! ✅`;

    try {
        if (fs.existsSync(bannerPath)) {
            await ctx.replyWithVideo(new InputFile(bannerPath), {
                caption, parse_mode: 'HTML', reply_markup: kb
            });
        } else {
            await ctx.reply(caption, { parse_mode: 'HTML', reply_markup: kb });
        }
    } catch (e) {
        await ctx.reply(caption, { parse_mode: 'HTML', reply_markup: kb });
    }
}

// ==================== MAIN INLINE KEYBOARD ====================
function getMainInlineKeyboard() {
    return new InlineKeyboard()
        .text('🔗 To URL — Upload Jadi Link', 'menu_tour_url')
        .row()
        .text('👥 Group Menu', 'menu_group')
        .row()
        .text('🤖 Chat AI — Rombak Project Otomatis', 'menu_chat_ai')
        .row()
        .text('🚀 Mulai Build APK', 'menu_zip')
        .text('🌐 Web to APK', 'menu_url')
        .row()
        .text('➕ Add Fitur', 'menu_add_fitur')
        .row()
        .text('🔧 Ganti Function', 'menu_ganti_function')
        .text('📄 Ganti File .dart', 'menu_ganti_dart')
        .row()
        .text('🧪 Tes Function', 'menu_tes_function')
        .text('🛠️ Fix Error Function', 'menu_fix_error')
        .row()
        .text('🎨 Recolour Project', 'menu_recolour')
        .text('🌈 Multi Recolour', 'menu_multi_recolour')
        .row()
        .text('✏️ Rename All (Domain/Nama Apk/Aset)', 'menu_rename_all')
        .row()
        .text('🆔 Rename Package ID (Android)', 'menu_rename_package')
        .row()
        .text('📁 Ganti Aset', 'menu_ganti_aset')
        .text('✏️ Rename Nama Apk', 'menu_rename_apk')
        .row()
        .text('📜 Rename Api/Script', 'menu_rename_api')
        .text('📦 Get Aset', 'menu_get_aset')
        .row()
        .text('💻 HTML → JS / Deploy', 'menu_html_js')
        .text('👁️ Preview Dart', 'menu_preview_dart')
        .row()
        .text('🔒 Enc Menu — Script/HTML', 'menu_enc')
        .row()
        .text('🔍 Cari di Project', 'menu_cari')
        .text('📊 Scan Info Project', 'menu_scan_info')
        .row()
        .text('🧹 Bersihkan Zip (Junk/Build)', 'menu_bersih_zip')
        .row()
        .text('📋 Antrian Build', 'menu_antrian')
        .text('📈 Statistik Build', 'menu_stats')
        .row()
        .text('⚙️ Status Bot', 'menu_status')
        .text('🏓 Ping Bot', 'menu_ping')
        .row()
        .text('💳 Credit & Referral', 'menu_credit')
        .row()
        .text('💰 Buy Credit', 'menu_buy_credit')
        .row()
        .url('👤 Owner ↗', config.contact.ownerUrl || 'https://t.me/yourusername')
        .url('📢 Channel ↗', config.contact.channelUrl || 'https://t.me/elxzchannel');
}

// ==================== HELPER ====================
function getProgressBar(p) {
    const f = Math.floor(p / 10);
    return '█'.repeat(f) + '░'.repeat(10 - f);
}

// ==================== LOG TO CHANNEL ====================
async function logBuildToChannel(status, data) {
    if (!config.logChannel || !config.logChannel.enabled || !config.logChannel.id) return;
    try {
        const {
            userId, username, firstName, fullName, name, projectFile, typeLabel, buildMode,
            sizeMB, errorMsg, detail, elapsedSec, progressStatus
        } = data;

        // Developer di log = orang yang lagi build (bukan owner bot)
        let builderName = fullName || firstName || null;
        if (!builderName && username) builderName = username;
        if (!builderName) builderName = `User ${userId}`;
        // tampilkan juga @username kalau ada
        if (username && !builderName.includes("@")) {
            builderName = `${builderName} (@${username})`;
        }

        const title = config.logChannel.title || "LIVE BUILD MONITOR";
        const proj = projectFile || name || "project.zip";
        const mode = buildMode ? `🚀 ${buildMode} Build` : "🚀 Release Build";
        const typeStr = typeLabel || "Flutter";

        // Hitung waktu berjalan
        let waktu = "—";
        if (typeof elapsedSec === "number" && elapsedSec >= 0) {
            const m = Math.floor(elapsedSec / 60);
            const s = elapsedSec % 60;
            waktu = `${m} Menit ${s} Detik`;
        }

        let statusEmoji = "🟡";
        let statusText = "STARTED";
        let progresLine = "STATUS → QUEUED";
        let detailLine = detail || "Memulai proses build...";

        if (status === "progress") {
            statusEmoji = "🔵";
            statusText = "PROGRESS";
            progresLine = `STATUS → ${(progressStatus || "BUILDING").toUpperCase()}`;
            detailLine = detail || "Proses sedang berjalan...";
        } else if (status === "success") {
            statusEmoji = "🟢";
            statusText = "SUCCESS";
            progresLine = "STATUS → COMPLETED";
            detailLine = detail || `Build sukses${sizeMB ? ` • ${sizeMB} MB` : ""}. APK dikirim ke user.`;
        } else if (status === "failed") {
            statusEmoji = "🔴";
            statusText = "FAILED";
            progresLine = "STATUS → ERROR";
            detailLine = detail || (errorMsg ? errorMsg.slice(0, 180) : "Build gagal.");
        }

        const text =
            `📦 <b>${title}</b> 📦\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `👤 <b>Developer</b> : ${builderName}\n` +
            `🆔 <b>User ID</b> : <code>${userId}</code>\n` +
            `📦 <b>Project</b> : <code>${proj}</code>\n` +
            `🔧 <b>Mode</b> : ${mode}\n` +
            `🏷 <b>Type</b> : ${typeStr}\n\n` +
            `📊 <b>PROGRES AKTIF:</b>\n` +
            `${progresLine}\n` +
            `DETAIL → ${detailLine}\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `⏱ <b>Waktu Berjalan:</b> ${waktu}\n` +
            `🤖 Multi-build Server Active — Proses berjalan independen.`;

        const kb = new InlineKeyboard()
            .text("🚀 Mau Build Juga?, Gas!", "menu_zip");

        // Prioritas: images/monitorlog.jpg (local) → kalau ada kirim foto
        const localMonitor = getImagePath('monitorlog');
        if (localMonitor) {
            try {
                await bot.api.sendPhoto(config.logChannel.id, new InputFile(localMonitor), {
                    caption: text,
                    parse_mode: "HTML",
                    reply_markup: kb
                });
                return;
            } catch (imgErr) {
                console.error("[LOG CHANNEL] Gagal kirim monitorlog.jpg:", imgErr.message);
            }
        }

        // Fallback teks saja
        await bot.api.sendMessage(config.logChannel.id, text, {
            parse_mode: "HTML",
            reply_markup: kb,
            disable_web_page_preview: true
        });
    } catch (e) {
        console.error("[LOG CHANNEL] Gagal kirim log:", e.message);
    }
}

function getWelcomeText(uid) {
    const credit = getCredit(uid);
    const badge = getRoleBadge(uid);
    return (
        `👋 Halo, <b>${uid}</b>!\n` +
        `Selamat datang di ASISTEN ELXZ BUILD ✨\n\n` +
        `🤖 <b>ASISTEN ELXZ BUILD v5.0.0</b>\n` +
        `Automated Flutter Cloud Compiler & Utility System\n\n` +
        `⭐ <b>Fitur Unggulan — AI Rombak Project</b>\n` +
        `Tinggal ketik instruksi pakai bahasa biasa, AI otomatis nyusun & nerapin perubahan ke project kamu.\n` +
        `Contoh: "Buat tema dark, tambah login Google, tambah bottom navigation"\n` +
        `🔴 Akses lewat menu ➕ Add Fitur setelah upload project ZIP.\n\n` +
        `🟢 Status: Online · Ready to Compile\n\n` +
        (badge ? `🏷 Role: <b>${badge}</b>\n` : '') +
        `🎟 <b>Credit:</b> ${credit}\n` +
        `📦 Setiap build menggunakan ${config.credit.costPerBuild} credit\n` +
        `🎉 Dapatkan ${config.credit.freePerWeek} credit gratis setiap minggu!\n\n` +
        `Pilih menu di bawah untuk mulai 👇`
    );
}

// ==================== GITHUB ====================
async function checkLocalBuildTools() {
    const { execSync } = require('child_process');
    const check = (cmd) => { try { execSync(cmd, { stdio: 'ignore', timeout: 5000 }); return true; } catch(_) { return false; } };
    return {
        flutter: check('flutter --version'),
        java:    check('java -version'),
        unzip:   check('unzip -v'),
    };
}

async function buildLocalApk(zipId, name, type, buildMode, TEMP_DIR, editMsg) {
    const { execSync } = require('child_process');
    const workDir = path.join(TEMP_DIR, `build_${Date.now()}_${name}`);
    const zipPath = path.join(workDir, 'project.zip');
    fs.mkdirSync(workDir, { recursive: true });

    await editMsg(`⬇️ <b>Mengunduh ZIP dari Telegram...</b>\n\n📱 <b>${name}</b>\n${getProgressBar(10)} 10%`);

    const fileInfo = await bot.api.getFile(zipId);
    const dlUrl    = `${LOCAL_API}/file/bot${BOT_TOKEN}/${fileInfo.file_path}`;
    const writer   = fs.createWriteStream(zipPath);
    const dlRes    = await axios({ method: 'GET', url: dlUrl, responseType: 'stream', timeout: 300000, maxContentLength: Infinity });
    await new Promise((res, rej) => { dlRes.data.pipe(writer); writer.on('finish', res); writer.on('error', rej); });

    await editMsg(`📦 <b>Mengekstrak project...</b>\n\n📱 <b>${name}</b>\n${getProgressBar(20)} 20%`);
    execSync(`unzip -o "${zipPath}" -d "${workDir}"`, { timeout: 60000 });

    let projectDir = workDir;
    const entries = fs.readdirSync(workDir).filter(f => f !== 'project.zip');
    if (entries.length === 1 && fs.statSync(path.join(workDir, entries[0])).isDirectory()) {
        projectDir = path.join(workDir, entries[0]);
    }

    await editMsg(`⚙️ <b>Menjalankan build Flutter...</b>\n\n📱 <b>${name}</b>\n${getProgressBar(35)} 35%\n📍 Ini mungkin butuh 5-15 menit...`);

    const isRelease = buildMode.toLowerCase() === 'release';
    let apkPath = null;

    if (type.includes('flutter')) {
        execSync(`cd "${projectDir}" && flutter pub get`, { timeout: 300000 });
        await editMsg(`⚙️ <b>Flutter pub get selesai, build APK...</b>\n\n📱 <b>${name}</b>\n${getProgressBar(55)} 55%`);
        execSync(`cd "${projectDir}" && flutter build apk --${isRelease ? 'release' : 'debug'} --no-shrink`, { timeout: 900000 });
        const found = execSync(`find "${projectDir}" -name "*.apk" 2>/dev/null`, { timeout: 10000 }).toString().trim().split('\n').filter(Boolean);
        apkPath = found.find(f => f.includes(isRelease ? 'release' : 'debug')) || found[0];
    } else {
        const gw = execSync(`find "${projectDir}" -name "gradlew" 2>/dev/null | head -1`, { timeout: 10000 }).toString().trim();
        if (gw) {
            execSync(`chmod +x "${gw}"`, { timeout: 5000 });
            const task = isRelease ? 'assembleRelease' : 'assembleDebug';
            execSync(`cd "$(dirname "${gw}")" && ./gradlew ${task}`, { timeout: 900000 });
            const found = execSync(`find "${projectDir}" -name "*.apk" 2>/dev/null`, { timeout: 10000 }).toString().trim().split('\n').filter(Boolean);
            apkPath = found.find(f => f.includes(isRelease ? 'release' : 'debug')) || found[0];
        }
    }

    if (!apkPath || !fs.existsSync(apkPath)) throw new Error('APK tidak ditemukan setelah build lokal selesai');
    return { apkPath, workDir };
}

async function triggerGitHub(uid, name, url, zipUrl = '') {
    const pkg = `com.ditzz.${name.toLowerCase().replace(/[^a-z0-9]/g, '')}`;
    const WORKFLOWS = ['build.yml', 'main.yml', 'flutter.yml', 'android.yml'];
    const BRANCHES  = ['main', 'master'];

    for (const branch of BRANCHES) {
        for (const wf of WORKFLOWS) {
            try {
                const res = await axios.post(
                    `https://api.github.com/repos/${config.github.owner}/${config.github.repo}/actions/workflows/${wf}/dispatches`,
                    { ref: branch, inputs: { url: url || '', app_name: name, package_name: pkg, user_id: uid.toString(), zip_url: zipUrl } },
                    { headers: { 'Authorization': `Bearer ${config.github.token}`, 'Accept': 'application/vnd.github.v3+json' }, timeout: 15000 }
                );
                console.log(`[GitHub] ✅ Trigger: ${wf}@${branch} status=${res.status}`);
                return { ok: true, workflow: wf, branch };
            } catch (e) {
                const status = e.response?.status;
                if (status === 422) {
                    try {
                        const r2 = await axios.post(
                            `https://api.github.com/repos/${config.github.owner}/${config.github.repo}/actions/workflows/${wf}/dispatches`,
                            { ref: branch },
                            { headers: { 'Authorization': `Bearer ${config.github.token}`, 'Accept': 'application/vnd.github.v3+json' }, timeout: 15000 }
                        );
                        return { ok: true, workflow: wf, branch };
                    } catch (_) {}
                }
                if (status === 404) continue;
                if (!e.response) return { ok: false, reason: 'network', message: e.message };
            }
        }
    }
    return { ok: false, reason: 'all_failed' };
}

async function uploadToGitHub(uid, name, zipId) {
    try { const f = await bot.api.getFile(zipId); return fileUrl(f.file_path); } catch(e) { return null; }
}

async function getLatestWorkflowRun(triggeredAfter) {
    try {
        const res = await axios.get(
            `https://api.github.com/repos/${config.github.owner}/${config.github.repo}/actions/runs?per_page=5`,
            { headers: { 'Authorization': `Bearer ${config.github.token}`, 'Accept': 'application/vnd.github.v3+json' }, timeout: 10000 }
        );
        return (res.data.workflow_runs || []).find(r => new Date(r.created_at).getTime() >= triggeredAfter) || null;
    } catch(e) { return null; }
}

async function getWorkflowArtifacts(runId) {
    try {
        const res = await axios.get(
            `https://api.github.com/repos/${config.github.owner}/${config.github.repo}/actions/runs/${runId}/artifacts`,
            { headers: { 'Authorization': `Bearer ${config.github.token}`, 'Accept': 'application/vnd.github.v3+json' }, timeout: 10000 }
        );
        return res.data.artifacts || [];
    } catch(e) { return []; }
}

async function downloadArtifact(artifactId, destPath) {
    const res = await axios.get(
        `https://api.github.com/repos/${config.github.owner}/${config.github.repo}/actions/artifacts/${artifactId}/zip`,
        { headers: { 'Authorization': `Bearer ${config.github.token}`, 'Accept': 'application/vnd.github.v3+json' },
          responseType: 'stream', maxRedirects: 5, timeout: 1800000, maxContentLength: Infinity, maxBodyLength: Infinity }
    );
    const writer = fs.createWriteStream(destPath);
    await new Promise((res, rej) => { res.data.pipe(writer); writer.on('finish', res); writer.on('error', rej); res.data.on('error', rej); });
}

async function extractApkFromArtifactZip(zipPath, destDir) {
    const AdmZip = (() => { try { return require('adm-zip'); } catch(_) { return null; } })();
    if (!AdmZip) {
        const { execSync } = require('child_process');
        execSync(`unzip -o "${zipPath}" -d "${destDir}"`, { timeout: 60000 });
    } else {
        new AdmZip(zipPath).extractAllTo(destDir, true);
    }
    function findApk(dir) {
        for (const f of fs.readdirSync(dir)) {
            const full = path.join(dir, f);
            if (fs.statSync(full).isDirectory()) { const found = findApk(full); if (found) return found; }
            else if (f.endsWith('.apk')) return full;
        }
        return null;
    }
    return findApk(destDir);
}

async function processBuild(job) {
    const { userId, name, url, type, zipId, username, firstName, fullName, projectFile } = job;
    const typeLabel  = type.includes('flutter') ? 'Flutter' : type.includes('android') ? 'Android Studio' : 'WebView';
    const buildMode  = type.includes('release') ? 'Release' : type.includes('debug') ? 'Debug' : 'Release';
    const apkName    = `${name}_${buildMode.toLowerCase()}.apk`;
    const startTime  = Date.now();
    const getElapsed = () => Math.floor((Date.now() - startTime) / 1000);
    const projName   = projectFile || (name ? `${name}.zip` : "project.zip");

    // Log start to channel (LIVE BUILD MONITOR)
    logBuildToChannel('start', {
        userId, username, firstName, fullName, name, projectFile: projName,
        typeLabel, buildMode, elapsedSec: 0,
        detail: "Menerima project & mempersiapkan lingkungan build..."
    }).catch(() => {});

    const msg = await bot.api.sendMessage(userId,
        `📱 App: <b>${name}</b>\n` +
        `🔧 Type: <b>${typeLabel} - ${buildMode}</b>\n` +
        `🎟 Sisa credit: ${getCredit(userId)}\n\n` +
        `⏳ Mempersiapkan build...`,
        { parse_mode: 'HTML' }
    );

    const editMsg = async (text) => {
        try { await bot.api.editMessageText(msg.chat.id, msg.message_id, text, { parse_mode: 'HTML' }); } catch (_) {}
    };

    const TEMP_DIR = path.join(__dirname, 'temp_apk');
    if (!fs.existsSync(TEMP_DIR)) fs.mkdirSync(TEMP_DIR, { recursive: true });
    const kbBack = new InlineKeyboard().text('\u21a9\uFE0F Kembali ke Menu', 'back_to_main');

    try {
        // ===== CEK APAKAH GITHUB BISA DIAKSES =====
        let githubReachable = false;
        try {
            await axios.get('https://api.github.com', { timeout: 5000 });
            githubReachable = true;
        } catch (_) {}

        // ===== CEK APAKAH ADA FLUTTER LOKAL =====
        const tools = await checkLocalBuildTools();
        const hasLocalBuild = tools.flutter || tools.java;

        console.log(`[BUILD] GitHub reachable: ${githubReachable} | Local tools: flutter=${tools.flutter} java=${tools.java}`);

        let apkPath    = null;
        let realSizeMB = '0.00';
        let workDir    = null;

        // ===== STRATEGI 1: BUILD LOKAL (jika Flutter/Java tersedia) =====
        if (hasLocalBuild && zipId) {
            await editMsg(
                `🔨 <b>Build Lokal Dimulai...</b>\n\n` +
                `📱 App: <b>${name}</b>\n` +
                `🔧 Type: <b>${typeLabel} - ${buildMode}</b>\n\n` +
                `${getProgressBar(5)} 5%`
            );
            try {
                const result = await buildLocalApk(zipId, name, type, buildMode, TEMP_DIR, editMsg);
                apkPath = result.apkPath;
                workDir = result.workDir;
                const sz = fs.statSync(apkPath).size;
                realSizeMB = (sz / 1024 / 1024).toFixed(2);
                console.log(`[BUILD] ✅ Build lokal sukses: ${apkPath} (${realSizeMB} MB)`);
            } catch (localErr) {
                console.warn('[BUILD] Build lokal gagal:', localErr.message);
                apkPath = null;
            }
        }

        // ===== STRATEGI 2: GITHUB ACTIONS (jika GitHub bisa diakses) =====
        if (!apkPath && githubReachable) {
            let zipPublicUrl = '';
            if (zipId) {
                try {
                    const fi = await bot.api.getFile(zipId);
                    if (fi.file_path) zipPublicUrl = `${LOCAL_API}/file/bot${BOT_TOKEN}/${fi.file_path}`;
                } catch (_) {}
            }

            await editMsg(
                `🚀 <b>Mengirim ke GitHub Actions...</b>\n\n` +
                `📱 App: <b>${name}</b>\n` +
                `🔧 Type: <b>${typeLabel} - ${buildMode}</b>\n\n` +
                `${getProgressBar(5)} 5%`
            );

            const triggerTime  = Date.now();
            const triggerResult = await triggerGitHub(userId, name, url || '', zipPublicUrl);

            if (triggerResult.ok) {
                console.log(`[BUILD] ✅ GitHub triggered: ${triggerResult.workflow}@${triggerResult.branch}`);
                const progressSteps = [
                    { pct: 15, text: 'Antrian GitHub Actions...' },
                    { pct: 30, text: 'Setup Flutter/Android SDK...' },
                    { pct: 50, text: 'Mengunduh dependencies...' },
                    { pct: 70, text: 'Menjalankan build task...' },
                    { pct: 85, text: 'Packaging APK...' },
                    { pct: 95, text: 'Finalisasi & upload artifact...' },
                ];
                let stepIdx = 0;
                let completedRun = null;
                const pollStart = Date.now();

                while (Date.now() - pollStart < 1800000) {
                    await new Promise(r => setTimeout(r, 15000));
                    const st = progressSteps[Math.min(stepIdx++, progressSteps.length - 1)];
                    await editMsg(
                        `⚙️ <b>Build GitHub Actions...</b>\n\n` +
                        `📱 App: <b>${name}</b>\n` +
                        `🔧 Type: <b>${typeLabel} - ${buildMode}</b>\n\n` +
                        `${getProgressBar(st.pct)} ${st.pct}%\n` +
                        `📍 ${st.text}`
                    );
                    const run = await getLatestWorkflowRun(triggerTime - 5000);
                    if (run && run.status === 'completed') { completedRun = run; break; }
                }

                if (completedRun && completedRun.conclusion === 'success') {
                    const artifacts = await getWorkflowArtifacts(completedRun.id);
                    if (artifacts.length) {
                        const art = artifacts.find(a =>
                            a.name.toLowerCase().includes('apk') ||
                            a.name.toLowerCase().includes(name.toLowerCase()) ||
                            a.name.toLowerCase().includes('release') ||
                            a.name.toLowerCase().includes('debug')
                        ) || artifacts[0];
                        const artZip  = path.join(TEMP_DIR, `${Date.now()}_art.zip`);
                        const artDir  = path.join(TEMP_DIR, `${Date.now()}_artdir`);
                        fs.mkdirSync(artDir, { recursive: true });
                        await downloadArtifact(art.id, artZip);
                        apkPath = await extractApkFromArtifactZip(artZip, artDir);
                        workDir = artDir;
                        try { fs.unlinkSync(artZip); } catch(_) {}
                        if (apkPath && fs.existsSync(apkPath)) {
                            realSizeMB = (fs.statSync(apkPath).size / 1024 / 1024).toFixed(2);
                            console.log(`[BUILD] ✅ GitHub artifact APK: ${apkPath} (${realSizeMB} MB)`);
                        } else { apkPath = null; }
                    }
                }
            }
        }

        // ===== STRATEGI 3: TIDAK ADA BUILD TOOLS → NOTIF ADMIN =====
        if (!apkPath) {
            // Kirim ZIP ke admin untuk diproses manual
            const adminId = config.bot.adminId;
            try {
                await bot.api.sendMessage(adminId,
                    `🔔 <b>Build Request Manual</b>\n━━━━━━━━━━━━━━━━━━\n\n` +
                    `👤 User ID: <code>${userId}</code>\n` +
                    `📱 App: <b>${name}</b>\n` +
                    `🔧 Type: <b>${typeLabel} - ${buildMode}</b>\n\n` +
                    `📦 File ZIP diteruskan di bawah.\n` +
                    `Setelah build selesai, kirim APK ke user dengan:\n` +
                    `<code>/sendapk ${userId}</code>`,
                    { parse_mode: 'HTML' }
                );
                if (zipId) await bot.api.forwardMessage(adminId, userId, msg.message_id - 1).catch(() => {
                    // forward zip langsung
                    bot.api.sendDocument(adminId, zipId, { caption: `ZIP untuk build: ${name}` }).catch(() => {});
                });
            } catch(_) {}

            throw new Error(
                `Tidak bisa build otomatis saat ini.\n\n` +
                `✅ <b>Yang sudah dilakukan:</b>\n` +
                `• ZIP kamu sudah diterima\n` +
                `• Admin sudah diberitahu\n\n` +
                `⏳ Admin akan memproses build manual dan mengirim APK ke kamu segera.\n\n` +
                `Hubungi ${config.contact.support} untuk info lebih lanjut.`
            );
        }

        // ===== KIRIM APK KE USER =====
        await editMsg(
            `✅ <b>Build Berhasil!</b>\n` +
            `━━━━━━━━━━━━━━━━━━\n\n` +
            `📱 App: <b>${name}</b>\n` +
            `🔧 Type: <b>${typeLabel}</b>\n` +
            `🔨 Build: <b>${buildMode}</b>\n` +
            `🎁 Ukuran: <b>${realSizeMB} MB</b>\n\n` +
            `📦 100%\n\n` +
            `🎉 Mengirim file APK...`
        );

        db.stats['success']++;
        saveDB();

        // Log success to channel (LIVE BUILD MONITOR)
        logBuildToChannel('success', {
            userId, username, firstName, fullName, name, projectFile: projName,
            typeLabel, buildMode, sizeMB: realSizeMB,
            elapsedSec: getElapsed(),
            detail: `Proses kompilasi sukses, APK ${realSizeMB} MB dikirim ke Telegram.`
        }).catch(() => {});


        const caption =
            `✅ <b>APK Build Success</b>\n` +
            `━━━━━━━━━━━━━━━━━━\n\n` +
            `📱 Type: <b>${typeLabel}</b>\n` +
            `🔨 Build: <b>${buildMode}</b>\n` +
            `🎁 Size: <b>${realSizeMB} MB</b>\n\n` +
            `<i>Generated by ${config.branding.name}</i>`;

        // Rename APK sesuai nama app
        const finalApk = path.join(workDir || TEMP_DIR, apkName);
        try { if (apkPath !== finalApk) fs.renameSync(apkPath, finalApk); apkPath = finalApk; } catch(_) {}

        let sent = false;
        try {
            await uploadDocumentMultipart(userId, apkPath, apkName, caption, {
                inline_keyboard: [[{ text: '\u21a9\uFE0F Kembali ke Menu', callback_data: 'back_to_main' }]]
            });
            sent = true;
        } catch(e1) {
            console.error('[BUILD] uploadDocumentMultipart gagal:', e1.message);
            try {
                await bot.api.sendDocument(userId,
                    new InputFile(fs.createReadStream(apkPath), apkName),
                    { caption, parse_mode: 'HTML', reply_markup: kbBack }
                );
                sent = true;
            } catch(e2) { console.error('[BUILD] grammy send gagal:', e2.message); }
        }

        // Cleanup
        try { if (workDir) fs.rmSync(workDir, { recursive: true, force: true }); } catch(_) {}

        if (!sent) {
            await bot.api.sendMessage(userId,
                `✅ APK berhasil dibuild tapi gagal dikirim.\nHubungi ${config.contact.support}`,
                { parse_mode: 'HTML', reply_markup: kbBack }
            ).catch(() => {});
        }

    } catch (err) {
        db.stats['failed']++;
        saveDB();
        // Log fail to channel (LIVE BUILD MONITOR)
        logBuildToChannel('failed', {
            userId, username, firstName, fullName, name, projectFile: projName,
            typeLabel, buildMode, errorMsg: err.message,
            elapsedSec: getElapsed(),
            detail: (err.message || "Unknown error").slice(0, 180)
        }).catch(() => {});

        console.error('[BUILD] ❌', err.message);
        await editMsg(
            `❌ <b>Build Gagal</b>\n━━━━━━━━━━━━━━━━━━\n\n` +
            `📱 App: <b>${name}</b>\n\n` +
            `⚠️ ${err.message}`
        ).catch(() => {});
    }

    // ===== LANJUTKAN ANTRIAN =====
    db.building = db.building.filter(j => j !== job);
    if (db.queue.length) {
        const next = db.queue.shift();
        db.building.push(next);
        processBuild(next);
    }
    saveDB();
}


bot.callbackQuery('check_join', async (ctx) => {
    await ctx.answerCallbackQuery({ text: '⏳ Sedang mengecek membership kamu...' });
    const uid = ctx.from.id;
    await new Promise(r => setTimeout(r, 1500));
    const joined = await isUserJoinedChannel(uid);
    if (joined) {
        const u = getUser(uid);
        u.joinedChannel = true;
        saveDB();
        await ctx.deleteMessage().catch(() => {});
        const bannerPath = path.join(__dirname, 'banner.mp4');
        const welcomeText = getWelcomeText(uid);
        try {
            if (fs.existsSync(bannerPath)) {
                await ctx.replyWithVideo(new InputFile(bannerPath), {
                    caption: welcomeText, parse_mode: 'HTML', reply_markup: getMainInlineKeyboard()
                });
            } else {
                await ctx.reply(welcomeText, { parse_mode: 'HTML', reply_markup: getMainInlineKeyboard() });
            }
        } catch (e) {
            await ctx.reply(welcomeText, { parse_mode: 'HTML', reply_markup: getMainInlineKeyboard() });
        }
    } else {
        await ctx.answerCallbackQuery({
            text: '❌ Kamu BELUM join channel!\n\nPastikan sudah join @elxzchannel lalu tekan tombol lagi.',
            show_alert: true
        });
    }
});

// ==================== COMMAND START ====================
bot.command('start', async (ctx) => {
    const uid = ctx.from.id;
    const joined = await checkJoin(ctx);
    if (!joined) return;
    const bannerPath = path.join(__dirname, 'banner.mp4');
    const welcomeText = getWelcomeText(uid);
    try {
        if (fs.existsSync(bannerPath)) {
            await ctx.replyWithVideo(new InputFile(bannerPath), {
                caption: welcomeText, parse_mode: 'HTML', reply_markup: getMainInlineKeyboard(), supports_streaming: true
            });
        } else {
            await ctx.reply(welcomeText, { parse_mode: 'HTML', reply_markup: getMainInlineKeyboard() });
        }
    } catch (e) {
        await ctx.reply(welcomeText, { parse_mode: 'HTML', reply_markup: getMainInlineKeyboard() });
    }

    // Kirim audio otomatis setelah welcome
    if (config.audio && config.audio.enabled && config.audio.fileIdOrUrl && config.audio.fileIdOrUrl !== 'YOUR_AUDIO_FILE_ID_HERE') {
        try {
            await ctx.replyWithAudio(config.audio.fileIdOrUrl, {
                title: config.audio.title || 'ELXZ BGM',
                performer: config.audio.performer || 'ELXZ OFFICIAL',
                duration: config.audio.duration || 0,
            });
        } catch (audioErr) {
            console.log('[Audio] Gagal kirim audio:', audioErr.message);
        }
    }
});

// ==================== INLINE MENU CALLBACKS ====================
bot.callbackQuery('menu_url', async (ctx) => {
    await ctx.answerCallbackQuery();
    const uid = ctx.from.id;
    if (!await checkJoin(ctx)) return;
    const credit = getCredit(uid);
    if (credit < config.credit.costPerBuild) {
        return ctx.reply(getCreditInfoText(uid), { parse_mode: 'HTML' });
    }
    const u = getUser(uid);
    u.step = 'waiting_url';
    saveDB();
    try { await ctx.deleteMessage(); } catch (e) {}
    const kb = new InlineKeyboard().text('❌ Batal', 'project_cancel');
    ctx.reply(
        `📱 <b>Buat APK Baru</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<b>Langkah 1/3: URL Website</b>\n\n` +
        `Silakan kirim URL website yang ingin dikonversi menjadi APK.\n\n` +
        `<i>Contoh: https://example.com</i>`,
        { parse_mode: 'HTML', reply_markup: kb }
    );
});

bot.callbackQuery('menu_zip', async (ctx) => {
    await ctx.answerCallbackQuery();
    const uid = ctx.from.id;
    if (!await checkJoin(ctx)) return;
    const credit = getCredit(uid);
    if (credit < config.credit.costPerBuild) {
        return ctx.reply(getCreditInfoText(uid), { parse_mode: 'HTML' });
    }
    try { await ctx.deleteMessage(); } catch (e) {}
    const kb = new InlineKeyboard()
        .text('📱🔴 Android Studio/Gradle 🔴📱', 'project_android')
        .row()
        .text('🐛🟢 Flutter Project 🟢🐛', 'project_flutter')
        .row()
        .text('❌ Batal', 'project_cancel');
    ctx.reply(
        `📦 <b>Build APK dari Project ZIP</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `Pilih jenis project yang akan di-build:\n\n` +
        `📱 <b>Android Studio</b>\n` +
        `Project dengan <code>build.gradle</code>\n\n` +
        `🐛 <b>Flutter</b>\n` +
        `Project dengan <code>pubspec.yaml</code>`,
        { parse_mode: 'HTML', reply_markup: kb }
    );
});

bot.callbackQuery('menu_tqto', async (ctx) => {
    await ctx.answerCallbackQuery();
    if (!await checkJoin(ctx)) return;
    ctx.reply(
        `━━━━━━━━━━━━━━━━━━\n\n` +
        `🙏 <b>Terima kasih kepada:</b>\n\n` +
        `👤 <b>Pengguna setia ASISTEN ELXZ BUILD</b>\n` +
        `   Kalian yang selalu support kami!\n\n` +
        `👤 <b>Member komunitas</b>\n` +
        `   Terus berkembang bersama!\n\n` +
        `💫 <b>Special thanks to:</b>\n` +
        `   @elxzchannel\n` +
        `   Sebagai support development 💫\n\n` +
        `💫 <b>Special thanks to:</b>\n` +
        `   @yourusername\n` +
        `   Sebagai support development 💫\n\n` +
        `💫 <b>Special thanks to:</b>\n` +
        `   @yourusername\n` +
        `   Sebagai support development 💫\n\n` +
        `💫 <b>Special thanks to:</b>\n` +
        `   @yourusername\n` +
        `   Sebagai Developer\n\n` +
        `━━━━━━━━━━━━━━━━━━\n` +
        `✨ Terima kasih sudah menggunakan <b>ASISTEN ELXZ BUILD</b>`,
        { parse_mode: 'HTML' }
    );
});

bot.callbackQuery('menu_bantuan', async (ctx) => {
    await ctx.answerCallbackQuery();
    if (!await checkJoin(ctx)) return;
    ctx.reply(
        `❓ <b>Bantuan & Support</b>\n\n` +
        `Hubungi owner/support:\n👤 ${config.contact.owner}\n\n` +
        `📌 <b>Cara Build APK:</b>\n` +
        `1. Pilih CREATE APK (URL) atau (ZIP)\n` +
        `2. Ikuti instruksi bot\n` +
        `3. Tunggu proses selesai\n` +
        `4. APK dikirim otomatis! ✅\n\n` +
        `🎟 Credit gratis ${config.credit.freePerWeek} setiap minggu.`,
        { parse_mode: 'HTML' }
    );
});

bot.callbackQuery('menu_antrian', async (ctx) => {
    await ctx.answerCallbackQuery();
    if (!await checkJoin(ctx)) return;
    const uid = ctx.from.id;
    const credit = getCredit(uid);
    const u = getUser(uid);

    const maxSlot = config.server.maxConcurrent;
    const isFull = db.building.length >= maxSlot;
    const serverStatus = isFull ? '🚨 Server: Penuh' : '✅ Server: Available';
    const slotInfo = `📊 Slot: ${db.building.length}/${maxSlot}`;

    let buildingText = '';
    if (db.building.length > 0) {
        buildingText = `\n⚙️ <b>Sedang Berjalan:</b>\n`;
        for (const j of db.building) {
            const elapsed = Math.floor((Date.now() - j.start) / 1000);
            const m = Math.floor(elapsed / 60);
            const s = elapsed % 60;
            const uInfo = db.users[j.userId];
            const uName = uInfo?.username ? `@${uInfo.username}` : `(${j.userId})`;
            buildingText += `• <b>${j.name}</b> ${uName} - ${j.type} (${m}m ${s}s)\n`;
        }
    } else {
        buildingText = `\n⚙️ <b>Sedang Berjalan:</b>\n• Tidak ada\n`;
    }

    let queueText = '';
    if (db.queue.length > 0) {
        queueText = `\n⏳ <b>Antrian (${db.queue.length}):</b>\n`;
        db.queue.forEach((j, i) => {
            const uInfo = db.users[j.userId];
            const uName = uInfo?.username ? `@${uInfo.username}` : `(${j.userId})`;
            queueText += `${i + 1}. <b>${j.name}</b> ${uName} - ${j.type}\n`;
        });
    } else {
        queueText = `\n⏳ <b>Antrian (0):</b>\n• Tidak ada\n`;
    }

    const avgTime = db.stats.success > 0
        ? Math.round(db.stats.avgTime || 237)
        : 237;

    const userStep = u.step ? `\n📝 <b>Anda sedang:</b> ${u.step}` : '';

    const caption =
        `📋 <b>Status Antrian Build</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `${serverStatus}\n` +
        `${slotInfo}\n` +
        `${buildingText}` +
        `${queueText}\n` +
        `📊 <b>Statistik:</b>\n` +
        `✅ ${db.stats.success} berhasil | ❌ ${db.stats.failed} gagal | ⏱ ~${avgTime}s\n` +
        `\n🎟 <b>Credit kamu: ${credit}</b>` +
        `${userStep}`;

    const kb = new InlineKeyboard()
        .text('🔄 Refresh', 'menu_antrian')
        .row()
        .text('↩️ Kembali ke Menu', 'back_to_main');

    ctx.reply(caption, { parse_mode: 'HTML', reply_markup: kb });
});

bot.callbackQuery('menu_perintah', async (ctx) => {
    await ctx.answerCallbackQuery();
    if (!await checkJoin(ctx)) return;
    const uid = ctx.from.id;
    const myRole = getUserRole(uid);
    let adminCmds = '';
    if (myRole === 'developer') {
        adminCmds =
            `\n\n💎 <b>Perintah Developer:</b>\n` +
            `/addowner &lt;id&gt; - Tambah Owner\n` +
            `/addtk &lt;id&gt; - Tambah TK\n` +
            `/addpt &lt;id&gt; - Tambah PT\n` +
            `/address &lt;id&gt; - Tambah RESS\n` +
            `/removerole &lt;id&gt; - Hapus role user\n` +
            `/listrole - Lihat semua role\n` +
            `/addcredit &lt;id&gt; &lt;jml&gt; - Tambah credit\n` +
            `/broadcast &lt;pesan&gt; - Broadcast ke semua user\n` +
            `/ownermenu - Menu admin`;
    } else if (myRole === 'owner') {
        adminCmds =
            `\n\n👑 <b>Perintah Owner:</b>\n` +
            `/addtk &lt;id&gt; - Tambah TK\n` +
            `/addpt &lt;id&gt; - Tambah PT\n` +
            `/address &lt;id&gt; - Tambah RESS\n` +
            `/listrole - Lihat semua role\n` +
            `/addcredit &lt;id&gt; &lt;jml&gt; - Tambah credit`;
    } else if (myRole === 'pt') {
        adminCmds =
            `\n\n🏢 <b>Perintah PT:</b>\n` +
            `/addcredit &lt;id&gt; &lt;jml&gt; - Tambah credit`;
    } else if (myRole === 'tk') {
        adminCmds =
            `\n\n🔰 <b>Perintah TK:</b>\n` +
            `/addcredit &lt;id&gt; &lt;jml&gt; - Tambah credit`;
    }
    ctx.reply(
        `📋 <b>Daftar Perintah</b>\n\n` +
        `/start - Mulai bot & tampilkan menu\n` +
        `/credit - Cek info credit lengkap\n` +
        `/myid - Lihat ID Telegram kamu\n` +
        `/myrole - Cek role kamu\n` +
        `/cancel - Batalkan proses aktif${adminCmds}`,
        { parse_mode: 'HTML' }
    );
});

// ==================== COMMAND CREDIT ====================
bot.command('credit', async (ctx) => {
    if (!await checkJoin(ctx)) return;
    const uid = ctx.from.id;
    const u = getUser(uid);
    const credit = getCredit(uid);
    const daysLeft = getTopupDaysLeft(uid);
    const totalUsed = u.totalUsed || 0;
    const totalReceived = u.totalReceived || credit;
    ctx.reply(
        `🎟 <b>INFO CREDIT</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
        `🎟 <b>Sisa Credit:</b> ${credit}\n` +
        `✅ <b>Total Digunakan:</b> ${totalUsed}\n` +
        `✅ <b>Total Diterima:</b> ${totalReceived}\n` +
        `⏰ <b>Topup Gratis:</b> ${daysLeft} hari lagi\n\n` +
        `📦 <i>Setiap build menggunakan ${config.credit.costPerBuild} credit</i>\n` +
        `🎉 <i>Dapatkan ${config.credit.freePerWeek} credit gratis setiap minggu!</i>\n\n` +
        `👤 Top up? Hubungi ${config.contact.owner}`,
        { parse_mode: 'HTML' }
    );
});

// ==================== CALLBACK TOMBOL BARU ====================
bot.callbackQuery('menu', async (ctx) => {
    await ctx.answerCallbackQuery({ text: '⏳ Loading...', show_alert: false });
    if (!await checkJoin(ctx)) return;
    const uid = ctx.from.id;
    const welcomeText = getWelcomeText(uid);
    try {
        await ctx.editMessageCaption({ caption: welcomeText, parse_mode: 'HTML', reply_markup: getMainInlineKeyboard() });
    } catch (e) {
        await ctx.reply(welcomeText, { parse_mode: 'HTML', reply_markup: getMainInlineKeyboard() });
    }
});


// ==================== ELXZ EXTRA MENU HANDLERS ====================
// Semua tombol berwarna dari menu utama — handler aman no-error

async function replyFeature(ctx, title, desc, callbackKey = null) {
    await ctx.answerCallbackQuery().catch(() => {});
    const kb = new InlineKeyboard().text('↩️ Kembali ke Menu', 'back_to_main');
    const text = `✨ <b>${title}</b>\n━━━━━━━━━━━━━━━━━━\n\n${desc}\n\n` +
        `📦 Upload project ZIP dulu lewat <b>🚀 Mulai Build APK</b> agar fitur ini bisa dipakai penuh.\n\n` +
        `🟢 Status fitur: Ready`;

    // Semua fitur pakai images/botlogo.jpg (cukup taruh file di folder images/)
    const localLogo = getImagePath('botlogo');

    try {
        if (localLogo) {
            try { await ctx.deleteMessage(); } catch (_) {}
            await ctx.replyWithPhoto(new InputFile(localLogo), {
                caption: text,
                parse_mode: 'HTML',
                reply_markup: kb
            });
        } else {
            try {
                await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: kb });
            } catch {
                await ctx.reply(text, { parse_mode: 'HTML', reply_markup: kb });
            }
        }
    } catch (e) {
        // Fallback paling aman (tanpa gambar)
        await ctx.reply(text, { parse_mode: 'HTML', reply_markup: kb }).catch(() => {});
    }
}

bot.callbackQuery('menu_to_url', async (ctx) => {
    await replyFeature(ctx, '🔗 To URL — Upload Jadi Link', 'Upload file (ZIP/APK/asset) dan dapatkan link download langsung.', 'menu_to_url');
});
bot.callbackQuery('menu_group', async (ctx) => {
    await replyFeature(ctx, '👥 Group Menu', 'Kelola bot di group / set group sebagai tempat notifikasi build.', 'menu_group');
});
bot.callbackQuery('menu_chat_ai', async (ctx) => {
    await replyFeature(ctx, '🤖 Chat AI — Rombak Project Otomatis', 'Ketik instruksi bahasa biasa. AI akan merombak struktur & kode Flutter project kamu secara otomatis.\n\nContoh: "Buat tema dark mode, tambah Google Login, bottom navigation"', 'menu_chat_ai');
});
bot.callbackQuery('menu_add_fitur', async (ctx) => {
    await replyFeature(ctx, '➕ Add Fitur', 'Tambahkan fitur baru ke project Flutter lewat perintah AI atau template siap pakai.', 'menu_add_fitur');
});
bot.callbackQuery('menu_ganti_function', async (ctx) => {
    await replyFeature(ctx, '🔧 Ganti Function', 'Ganti / rewrite function tertentu di file .dart project.', 'menu_ganti_function');
});
bot.callbackQuery('menu_ganti_dart', async (ctx) => {
    await replyFeature(ctx, '📄 Ganti File .dart', 'Replace isi file .dart tertentu dengan kode baru.', 'menu_ganti_dart');
});
bot.callbackQuery('menu_tes_function', async (ctx) => {
    await replyFeature(ctx, '🧪 Tes Function', 'Jalankan test sederhana terhadap function di project.', 'menu_tes_function');
});
bot.callbackQuery('menu_fix_error', async (ctx) => {
    await replyFeature(ctx, '🛠️ Fix Error Function', 'Kirim error log, bot akan coba auto-fix kode yang bermasalah.', 'menu_fix_error');
});
bot.callbackQuery('menu_recolour', async (ctx) => {
    await replyFeature(ctx, '🎨 Recolour Project', 'Ganti warna utama (primary/secondary) di seluruh project Flutter.', 'menu_recolour');
});
bot.callbackQuery('menu_multi_recolour', async (ctx) => {
    await replyFeature(ctx, '🌈 Multi Recolour', 'Ganti banyak warna sekaligus (theme, button, accent, dll).', 'menu_multi_recolour');
});
bot.callbackQuery('menu_rename_all', async (ctx) => {
    await replyFeature(ctx, '✏️ Rename All', 'Rename domain, nama APK, dan aset sekaligus dalam satu perintah.', 'menu_rename_all');
});
bot.callbackQuery('menu_rename_package', async (ctx) => {
    await replyFeature(ctx, '🆔 Rename Package ID (Android)', 'Ganti applicationId / package name Android (com.xxx.yyy).', 'menu_rename_package');
});
bot.callbackQuery('menu_ganti_aset', async (ctx) => {
    await replyFeature(ctx, '📁 Ganti Aset', 'Replace icon, splash, image, font di folder assets.', 'menu_ganti_aset');
});
bot.callbackQuery('menu_rename_apk', async (ctx) => {
    await replyFeature(ctx, '✏️ Rename Nama Apk', 'Ubah label name & output filename APK.', 'menu_rename_apk');
});
bot.callbackQuery('menu_rename_api', async (ctx) => {
    await replyFeature(ctx, '📜 Rename Api/Script', 'Rename endpoint API atau script name di project.', 'menu_rename_api');
});
bot.callbackQuery('menu_get_aset', async (ctx) => {
    await replyFeature(ctx, '📦 Get Aset', 'Extract dan kirim kembali folder assets dari project ZIP.', 'menu_get_aset');
});
bot.callbackQuery('menu_html_js', async (ctx) => {
    await replyFeature(ctx, '💻 HTML → JS / Deploy', 'Convert HTML/JS project atau prepare untuk deploy.', 'menu_html_js');
});
bot.callbackQuery('menu_preview_dart', async (ctx) => {
    await replyFeature(ctx, '👁️ Preview Dart', 'Preview struktur file .dart utama project.', 'menu_preview_dart');
});
bot.callbackQuery('menu_enc', async (ctx) => {
    await replyFeature(ctx, '🔒 Enc Menu — Script/HTML', 'Encrypt / obfuscate script atau HTML di project.', 'menu_enc');
});
bot.callbackQuery('menu_cari', async (ctx) => {
    await replyFeature(ctx, '🔍 Cari di Project', 'Search string / class / function di dalam project ZIP.', 'menu_cari');
});
bot.callbackQuery('menu_scan_info', async (ctx) => {
    await replyFeature(ctx, '📊 Scan Info Project', 'Scan package name, version, dependencies, dan info penting project.', 'menu_scan_info');
});
bot.callbackQuery('menu_bersih_zip', async (ctx) => {
    await replyFeature(ctx, '🧹 Bersihkan Zip (Junk/Build)', 'Hapus folder build, .dart_tool, junk file agar ZIP lebih kecil.', 'menu_bersih_zip');
});
bot.callbackQuery('menu_stats', async (ctx) => {
    await ctx.answerCallbackQuery();
    const s = db.stats || { success: 0, failed: 0 };
    const kb = new InlineKeyboard().text('↩️ Kembali', 'back_to_main');
    const text = `📈 <b>Statistik Build</b>\n━━━━━━━━━━━━━━━━━━\n\n` +
        `✅ Success: <b>${s.success || 0}</b>\n` +
        `❌ Failed: <b>${s.failed || 0}</b>\n` +
        `📋 Antrian: <b>${(db.queue || []).length}</b>\n` +
        `⚙️ Sedang Build: <b>${(db.building || []).length}</b>\n\n` +
        `🤖 ${config.branding.name}`;
    try { await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: kb }); }
    catch { await ctx.reply(text, { parse_mode: 'HTML', reply_markup: kb }); }
});
bot.callbackQuery('menu_status', async (ctx) => {
    await ctx.answerCallbackQuery({ text: '🟢 Bot Online — Ready to Compile', show_alert: true });
});
bot.callbackQuery('menu_ping', async (ctx) => {
    const start = Date.now();
    await ctx.answerCallbackQuery();
    const ms = Date.now() - start;
    await ctx.reply(`🏓 <b>Pong!</b>\nLatency: <code>${ms} ms</code>\n🟢 Status: Online`, { parse_mode: 'HTML' });
});
bot.callbackQuery('menu_credit', async (ctx) => {
    await ctx.answerCallbackQuery();
    const uid = ctx.from.id;
    const text = getCreditInfoText(uid);
    const kb = new InlineKeyboard()
        .text('💰 Buy Credit', 'menu_buy_credit')
        .row()
        .text('↩️ Kembali', 'back_to_main');
    try { await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: kb }); }
    catch { await ctx.reply(text, { parse_mode: 'HTML', reply_markup: kb }); }
});
bot.callbackQuery('menu_buy_credit', async (ctx) => {
    await replyFeature(ctx, '💰 Buy Credit', `Hubungi ${config.contact.support} untuk top-up credit.\n\nAtau gunakan sistem referral untuk dapat credit gratis.`, 'menu_buy_credit');
});

bot.callbackQuery('back_to_main', async (ctx) => {
    await ctx.answerCallbackQuery({ text: '🩸 Loading', show_alert: false });
    const uid = ctx.from.id;
    const welcomeText = getWelcomeText(uid);
    try {
        await ctx.editMessageCaption({ caption: welcomeText, parse_mode: 'HTML', reply_markup: getMainInlineKeyboard() });
    } catch (e) {
        await ctx.reply(welcomeText, { parse_mode: 'HTML', reply_markup: getMainInlineKeyboard() });
    }
});

// ==================== COMMAND MYROLE ====================
bot.command('myrole', async (ctx) => {
    const uid = ctx.from.id;
    const role = getUserRole(uid);
    const badge = getRoleBadge(uid);
    if (!role) {
        return ctx.reply(`👤 <b>Role Kamu</b>\n\nKamu tidak memiliki role khusus.\nRole: <b>User Biasa</b>`, { parse_mode: 'HTML' });
    }
    ctx.reply(
        `👤 <b>Role Kamu</b>\n\n` +
        `${badge}\n` +
        `Level: ${ROLE_INFO[role].level}\n\n` +
        `<i>Gunakan /menu_perintah untuk melihat akses kamu.</i>`,
        { parse_mode: 'HTML' }
    );
});

// ==================== COMMAND LISTROLE ====================
bot.command('listrole', async (ctx) => {
    const uid = ctx.from.id;
    if (!isOwnerOrAbove(uid)) return ctx.reply('❌ Akses ditolak.');
    const devs = db.roles.developer.length ? db.roles.developer.join(', ') : 'Kosong';
    const owners = db.roles.owner.length ? db.roles.owner.join(', ') : 'Kosong';
    const tks = db.roles.tk.length ? db.roles.tk.join(', ') : 'Kosong';
    const pts = db.roles.pt.length ? db.roles.pt.join(', ') : 'Kosong';
    const resss = db.roles.ress.length ? db.roles.ress.join(', ') : 'Kosong';
    ctx.reply(
        `👥 <b>DAFTAR ROLE</b>\n` +
        `━━━━━━━━━━━━━━━━━━\n\n` +
        `💎 <b>DEVELOPER (Lv.1)</b>\n└ ${devs}\n\n` +
        `👑 <b>OWNER (Lv.2)</b>\n└ ${owners}\n\n` +
        `🔰 <b>TK (Lv.3)</b>\n└ ${tks}\n\n` +
        `🏢 <b>PT (Lv.4)</b>\n└ ${pts}\n\n` +
        `🎯 <b>RESS (Lv.5)</b>\n└ ${resss}`,
        { parse_mode: 'HTML' }
    );
});

// ==================== /addowner ====================
bot.command('addowner', async (ctx) => {
    const uid = ctx.from.id;
    if (!isDeveloper(uid)) return ctx.reply('❌ Hanya <b>Developer</b> yang bisa menambah Owner!', { parse_mode: 'HTML' });
    const args = ctx.message.text.split(' ');
    const targetId = args[1];
    if (!targetId) return ctx.reply('❌ Format: /addowner &lt;user_id&gt;\nContoh: /addowner 123456789', { parse_mode: 'HTML' });
    if (targetId === config.bot.adminId) return ctx.reply('❌ Tidak bisa ubah role root developer!');
    addRole(targetId, 'owner');
    await ctx.reply(
        `✅ <b>Berhasil!</b>\n\n` +
        `👑 User <code>${targetId}</code> sekarang menjadi <b>OWNER</b>\n` +
        `Level: 2 (No. 2 tertinggi)\n\n` +
        `Akses: Tambah TK, PT, RESS`,
        { parse_mode: 'HTML' }
    );
    try {
        await bot.api.sendMessage(targetId,
            `🎉 <b>Selamat!</b>\n\nKamu telah diberi role <b>👑 OWNER</b> oleh Developer!\n\nGunakan /myrole untuk cek role kamu.`,
            { parse_mode: 'HTML' }
        );
    } catch (e) {}
});

// ==================== /addtk ====================
bot.command('addtk', async (ctx) => {
    const uid = ctx.from.id;
    if (!canAddRole(uid, 'tk')) return ctx.reply('❌ Hanya <b>Developer</b> atau <b>Owner</b> yang bisa menambah TK!', { parse_mode: 'HTML' });
    const args = ctx.message.text.split(' ');
    const targetId = args[1];
    if (!targetId) return ctx.reply('❌ Format: /addtk &lt;user_id&gt;\nContoh: /addtk 123456789', { parse_mode: 'HTML' });
    if (targetId === config.bot.adminId) return ctx.reply('❌ Tidak bisa ubah role root developer!');
    addRole(targetId, 'tk');
    await ctx.reply(
        `✅ <b>Berhasil!</b>\n\n` +
        `🔰 User <code>${targetId}</code> sekarang menjadi <b>TK</b>\n` +
        `Level: 3`,
        { parse_mode: 'HTML' }
    );
    try {
        await bot.api.sendMessage(targetId,
            `🎉 <b>Selamat!</b>\n\nKamu telah diberi role <b>🔰 TK</b>!\n\nGunakan /myrole untuk cek role kamu.`,
            { parse_mode: 'HTML' }
        );
    } catch (e) {}
});

// ==================== /addpt ====================
bot.command('addpt', async (ctx) => {
    const uid = ctx.from.id;
    if (!canAddRole(uid, 'pt')) return ctx.reply('❌ Hanya <b>Developer</b> atau <b>Owner</b> yang bisa menambah PT!', { parse_mode: 'HTML' });
    const args = ctx.message.text.split(' ');
    const targetId = args[1];
    if (!targetId) return ctx.reply('❌ Format: /addpt &lt;user_id&gt;\nContoh: /addpt 123456789', { parse_mode: 'HTML' });
    if (targetId === config.bot.adminId) return ctx.reply('❌ Tidak bisa ubah role root developer!');
    addRole(targetId, 'pt');
    await ctx.reply(
        `✅ <b>Berhasil!</b>\n\n` +
        `🏢 User <code>${targetId}</code> sekarang menjadi <b>PT</b>\n` +
        `Level: 4`,
        { parse_mode: 'HTML' }
    );
    try {
        await bot.api.sendMessage(targetId,
            `🎉 <b>Selamat!</b>\n\nKamu telah diberi role <b>🏢 PT</b>!\n\nGunakan /myrole untuk cek role kamu.`,
            { parse_mode: 'HTML' }
        );
    } catch (e) {}
});

// ==================== /address ====================
bot.command('address', async (ctx) => {
    const uid = ctx.from.id;
    if (!canAddRole(uid, 'ress')) return ctx.reply('❌ Hanya <b>Developer</b> atau <b>Owner</b> yang bisa menambah RESS!', { parse_mode: 'HTML' });
    const args = ctx.message.text.split(' ');
    const targetId = args[1];
    if (!targetId) return ctx.reply('❌ Format: /address &lt;user_id&gt;\nContoh: /address 123456789', { parse_mode: 'HTML' });
    if (targetId === config.bot.adminId) return ctx.reply('❌ Tidak bisa ubah role root developer!');
    addRole(targetId, 'ress');
    await ctx.reply(
        `✅ <b>Berhasil!</b>\n\n` +
        `🎯 User <code>${targetId}</code> sekarang menjadi <b>RESS</b>\n` +
        `Level: 5`,
        { parse_mode: 'HTML' }
    );
    try {
        await bot.api.sendMessage(targetId,
            `🎉 <b>Selamat!</b>\n\nKamu telah diberi role <b>🎯 RESS</b>!\n\nGunakan /myrole untuk cek role kamu.`,
            { parse_mode: 'HTML' }
        );
    } catch (e) {}
});

// ==================== /removerole ====================
bot.command('removerole', async (ctx) => {
    const uid = ctx.from.id;
    if (!isOwnerOrAbove(uid)) return ctx.reply('❌ Akses ditolak.');
    const args = ctx.message.text.split(' ');
    const targetId = args[1];
    if (!targetId) return ctx.reply('❌ Format: /removerole &lt;user_id&gt;', { parse_mode: 'HTML' });
    if (targetId === config.bot.adminId) return ctx.reply('❌ Tidak bisa hapus role root developer!');
    if (!canRemoveRole(uid, targetId)) return ctx.reply('❌ Kamu tidak punya izin untuk menghapus role user ini!');
    const oldRole = getUserRole(targetId);
    if (!oldRole) return ctx.reply(`❌ User <code>${targetId}</code> tidak memiliki role.`, { parse_mode: 'HTML' });
    removeRole(targetId);
    await ctx.reply(
        `✅ <b>Role dihapus!</b>\n\nUser <code>${targetId}</code> (${ROLE_INFO[oldRole]?.emoji} ${ROLE_INFO[oldRole]?.label}) sudah kembali menjadi user biasa.`,
        { parse_mode: 'HTML' }
    );
    try {
        await bot.api.sendMessage(targetId, `⚠️ Role kamu telah dihapus oleh admin.\n\nGunakan /myrole untuk cek status kamu.`);
    } catch (e) {}
});

// ==================== PROJECT CALLBACKS ====================
bot.callbackQuery('project_android', async (ctx) => {
    await ctx.answerCallbackQuery();
    const uid = ctx.from.id;
    const u = getUser(uid);
    u.zipType = 'android';
    u.step = 'zip_buildtype';
    saveDB();
    try { await ctx.deleteMessage(); } catch (e) {}
    const kb = new InlineKeyboard()
        .text('🚀 Debug APK (Fast)', 'zip_debug')
        .row()
        .text('🐛 Release APK', 'zip_release')
        .row()
        .text('❌ Batal', 'project_cancel');
    ctx.reply(
        `📱 <b>Project: Android Studio</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `Pilih tipe build:\n\n` +
        `🚀 <b>Debug</b> - Build cepat untuk testing\n` +
        `🐛 <b>Release</b> - Build untuk produksi`,
        { parse_mode: 'HTML', reply_markup: kb }
    );
});

bot.callbackQuery('project_flutter', async (ctx) => {
    await ctx.answerCallbackQuery();
    const uid = ctx.from.id;
    const u = getUser(uid);
    u.zipType = 'flutter';
    u.step = 'zip_buildtype';
    saveDB();
    try { await ctx.deleteMessage(); } catch (e) {}
    const kb = new InlineKeyboard()
        .text('🚀 Debug APK (Fast)', 'zip_debug')
        .row()
        .text('🐛 Release APK', 'zip_release')
        .row()
        .text('❌ Batal', 'project_cancel');
    ctx.reply(
        `🐛 <b>Project: Flutter</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `Pilih tipe build:\n\n` +
        `🚀 <b>Debug</b> - Build cepat untuk testing\n` +
        `🐛 <b>Release</b> - Build untuk produksi`,
        { parse_mode: 'HTML', reply_markup: kb }
    );
});

bot.callbackQuery('zip_debug', async (ctx) => {
    await ctx.answerCallbackQuery();
    const uid = ctx.from.id;
    const u = getUser(uid);
    u.zipBuild = 'debug';
    u.step = 'waiting_zip';
    saveDB();
    // Hapus pesan tombol sebelumnya
    try { await ctx.deleteMessage(); } catch (e) {}
    const kb = new InlineKeyboard().text('❌ Batal', 'project_cancel');
    ctx.reply(
        `⬆️ <b>Upload Project ZIP</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `Project: <b>${u.zipType === 'flutter' ? 'Flutter' : 'Android Studio'}</b>\n` +
        `Build: 🚀 <b>Debug</b>\n\n` +
        `Silakan kirim file <b>.zip</b> project Anda.\n\n` +
        `⚠️ <i>Pastikan project sudah bisa di-build sebelumnya.</i>`,
        { parse_mode: 'HTML', reply_markup: kb }
    );
});

bot.callbackQuery('zip_release', async (ctx) => {
    await ctx.answerCallbackQuery();
    const uid = ctx.from.id;
    const u = getUser(uid);
    u.zipBuild = 'release';
    u.step = 'waiting_zip';
    saveDB();
    // Hapus pesan tombol sebelumnya
    try { await ctx.deleteMessage(); } catch (e) {}
    const kb = new InlineKeyboard().text('❌ Batal', 'project_cancel');
    ctx.reply(
        `⬆️ <b>Upload Project ZIP</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `Project: <b>${u.zipType === 'flutter' ? 'Flutter' : 'Android Studio'}</b>\n` +
        `Build: 🐛 <b>Release</b>\n\n` +
        `Silakan kirim file <b>.zip</b> project Anda.\n\n` +
        `⚠️ <i>Pastikan project sudah bisa di-build sebelumnya.</i>`,
        { parse_mode: 'HTML', reply_markup: kb }
    );
});

bot.callbackQuery('project_cancel', async (ctx) => {
    await ctx.answerCallbackQuery({ text: '❌ Dibatalkan' });
    const uid = ctx.from.id;
    const u = getUser(uid);
    u.step = null;
    u.zipType = null;
    u.zipBuild = null;
    saveDB();
    // Hapus pesan tombol, langsung kembali ke menu utama
    try { await ctx.deleteMessage(); } catch (e) {}
    const welcomeText = getWelcomeText(uid);
    const bannerPath = path.join(__dirname, 'banner.mp4');
    try {
        if (fs.existsSync(bannerPath)) {
            await ctx.replyWithVideo(new InputFile(bannerPath), {
                caption: welcomeText, parse_mode: 'HTML', reply_markup: getMainInlineKeyboard(), supports_streaming: true
            });
        } else {
            await ctx.reply(welcomeText, { parse_mode: 'HTML', reply_markup: getMainInlineKeyboard() });
        }
    } catch (e) {
        await ctx.reply(welcomeText, { parse_mode: 'HTML', reply_markup: getMainInlineKeyboard() });
    }
});

// ==================== DOCUMENT HANDLER ====================
bot.on(':document', async (ctx) => {
    const uid = ctx.from.id;
    if (!await checkJoin(ctx)) return;
    const u = getUser(uid);
    if (!u || u.step !== 'waiting_zip') return;
    const doc = ctx.message.document;
    if (!doc.file_name?.endsWith('.zip')) return ctx.reply('❌ Hanya file .zip yang diterima!');
    if (!useCredit(uid)) {
        return ctx.reply(getCreditInfoText(uid), { parse_mode: 'HTML' });
    }
    u.zipFile = doc.file_id;
    u.appName = doc.file_name.replace('.zip', '');
    const buildType = u.zipBuild || 'release';
    const projType = u.zipType || 'flutter';
    u.step = null;
    saveDB();
    ctx.reply(
        `✅ <b>File ZIP diterima!</b>\n\n` +
        `📱 App: <b>${u.appName}</b>\n` +
        `🔧 Type: <b>${projType}</b> - <b>${buildType}</b>\n` +
        `🎟 Sisa credit: ${getCredit(uid)}\n\n` +
        `🚀 Build dimulai...`,
        { parse_mode: 'HTML' }
    );
    const fname = (doc.file_name || `${u.appName}.zip`).slice(0, 80);
    const from = ctx.from || {};
    const fullName = [from.first_name, from.last_name].filter(Boolean).join(" ").trim() || null;
    addToQueue(uid, u.appName, null, `${projType}-${buildType}`, doc.file_id, {
        username: from.username || null,
        firstName: from.first_name || null,
        fullName: fullName,
        projectFile: fname
    });
});

// ==================== TEXT HANDLER ====================
bot.on(':text', async (ctx) => {
    const uid = ctx.from.id;
    const u = getUser(uid);
    const txt = ctx.message.text;
    if (!u?.step) return;

    if (u.step === 'waiting_url') {
        if (!await checkJoin(ctx)) return;
        if (!txt.startsWith('http')) return ctx.reply('❌ URL harus diawali http:// atau https://');
        u.url = txt;
        u.step = 'waiting_name';
        saveDB();
        ctx.reply('📝 Masukkan nama aplikasi kamu:');
    } else if (u.step === 'waiting_name') {
        if (!await checkJoin(ctx)) return;
        u.appName = txt.substring(0, 30);
        u.step = null;
        saveDB();
        if (!useCredit(uid)) {
            return ctx.reply(getCreditInfoText(uid), { parse_mode: 'HTML' });
        }
        ctx.reply(`✅ Build <b>${u.appName}</b> dimulai!\n🎟 Sisa credit: ${getCredit(uid)}`, { parse_mode: 'HTML' });
        const from = ctx.from || {};
        const fullName = [from.first_name, from.last_name].filter(Boolean).join(" ").trim() || null;
        addToQueue(uid, u.appName, u.url, 'url', null, {
            username: from.username || null,
            firstName: from.first_name || null,
            fullName: fullName,
            projectFile: `${u.appName}_web.zip`
        });
    } else if (u.step === 'waiting_broadcast_tele') {
        u.step = null; saveDB();
        await ctx.reply('📡 <b>Mengirim broadcast ke semua user...</b>', { parse_mode: 'HTML' });
        await doBroadcast(txt, ctx);
    } else if (u.step === 'waiting_addcredit_step') {
        const parts = txt.trim().split(/\s+/);
        const targetId = parts[0];
        const amount = parseInt(parts[1]);
        if (!targetId || isNaN(amount) || amount <= 0) {
            return ctx.reply('❌ Format: <code>ID jumlah</code>\nContoh: <code>123456789 10</code>', { parse_mode: 'HTML' });
        }
        getUser(targetId);
        addCredit(targetId, amount);
        u.step = null; saveDB();
        const newTotal = getCredit(targetId);
        await ctx.reply(
            `✅ <b>Berhasil!</b>\n\n` +
            `🆔 User: <code>${targetId}</code>\n` +
            `➕ Ditambah: <b>+${amount} credit</b>\n` +
            `🎟 Total sekarang: <b>${newTotal}</b>`,
            { parse_mode: 'HTML' }
        );
        try {
            await bot.api.sendMessage(targetId,
                `🎉 <b>Credit Kamu Bertambah!</b>\n\n➕ <b>+${amount} credit</b> ditambahkan\n🎟 Total: <b>${newTotal}</b>`,
                { parse_mode: 'HTML' }
            );
        } catch(e) {}
    } else if (u.step === 'waiting_addcredit') {
        const parts = txt.trim().split(/\s+/);
        const targetId = parts[0];
        const amount = parseInt(parts[1]);
        if (!targetId || isNaN(amount) || amount <= 0) {
            return ctx.reply('❌ Format: <code>ID jumlah</code>\nContoh: <code>123456789 10</code>', { parse_mode: 'HTML' });
        }
        getUser(targetId);
        addCredit(targetId, amount);
        u.step = null; saveDB();
        const newTotal2 = getCredit(targetId);
        await ctx.reply(
            `✅ <b>Berhasil!</b>\n\n🆔 User: <code>${targetId}</code>\n➕ Ditambah: <b>+${amount} credit</b>\n🎟 Total: <b>${newTotal2}</b>`,
            { parse_mode: 'HTML' }
        );
        try {
            await bot.api.sendMessage(targetId,
                `🎉 <b>Credit Kamu Bertambah!</b>\n\n➕ <b>+${amount} credit</b>\n🎟 Total: <b>${newTotal2}</b>`,
                { parse_mode: 'HTML' }
            );
        } catch(e) {}
    }
});

// ==================== OWNER MENU ====================
bot.command('ownermenu', async (ctx) => {
    if (!isOwnerOrAbove(ctx.from.id)) return ctx.reply('❌ Akses ditolak.');
    const uid = ctx.from.id;
    const myRole = getUserRole(uid);
    const totalUsers = Object.keys(db.users).length;
    const totalWebUsers = Object.keys(db.webUsers).length;
    let kb = new InlineKeyboard()
        .text('📢 Broadcast Telegram', 'owner_broadcast_tele').row()
        .text('🎟 Tambah Credit User', 'owner_addcredit').row()
        .text('📊 Stats', 'owner_stats').row()
        .text('👥 Lihat Semua Role', 'owner_listrole');

    // Tombol tambahan khusus Developer
    if (isDeveloper(uid)) {
        kb = kb.row().text('💎 Kelola Developer', 'owner_devmenu');
    }

    ctx.reply(
        `${getRoleBadge(uid)} <b>MENU ADMIN</b>\n` +
        `━━━━━━━━━━━━━━━━━━\n\n` +
        `👥 User Telegram: ${totalUsers}\n` +
        `🌐 User Web: ${totalWebUsers}\n` +
        `⏳ Antrian: ${db.queue.length}\n` +
        `🔨 Building: ${db.building.length}\n` +
        `✅ Sukses: ${db.stats.success} | ❌ Gagal: ${db.stats.failed}\n\n` +
        `💎 Developer: ${db.roles.developer.length}\n` +
        `👑 Owner: ${db.roles.owner.length}\n` +
        `🔰 TK: ${db.roles.tk.length}\n` +
        `🏢 PT: ${db.roles.pt.length}\n` +
        `🎯 RESS: ${db.roles.ress.length}`,
        { parse_mode: 'HTML', reply_markup: kb }
    );
});

bot.callbackQuery('owner_stats', async (ctx) => {
    await ctx.answerCallbackQuery();
    ctx.reply(`📊 Stats\n✅ ${db.stats.success} Sukses | ❌ ${db.stats.failed} Gagal`);
});

bot.callbackQuery('owner_broadcast_tele', async (ctx) => {
    await ctx.answerCallbackQuery();
    if (!isDeveloper(ctx.from.id)) return ctx.answerCallbackQuery({ text: '❌ Hanya Developer yang bisa broadcast!', show_alert: true });
    const u = getUser(ctx.from.id);
    u.step = 'waiting_broadcast_tele'; saveDB();
    ctx.reply('📢 Kirim pesan broadcast:');
});

bot.callbackQuery('owner_addcredit', async (ctx) => {
    await ctx.answerCallbackQuery();
    if (!isOwnerOrAbove(ctx.from.id)) return;
    const u = getUser(ctx.from.id);
    u.step = 'waiting_addcredit'; saveDB();
    ctx.reply(
        '🎟 <b>Tambah Credit User</b>\n━━━━━━━━━━━━━━━━━━\n\n' +
        'Kirim dalam format:\n<code>ID_user jumlah_credit</code>\n\n' +
        'Contoh: <code>123456789 10</code>\n\n' +
        '<i>Tip: Minta user kirim /myid untuk dapat ID mereka</i>',
        { parse_mode: 'HTML' }
    );
});

bot.callbackQuery('owner_listrole', async (ctx) => {
    await ctx.answerCallbackQuery();
    if (!isOwnerOrAbove(ctx.from.id)) return;
    const devs = db.roles.developer.length ? db.roles.developer.join(', ') : 'Kosong';
    const owners = db.roles.owner.length ? db.roles.owner.join(', ') : 'Kosong';
    const tks = db.roles.tk.length ? db.roles.tk.join(', ') : 'Kosong';
    const pts = db.roles.pt.length ? db.roles.pt.join(', ') : 'Kosong';
    const resss = db.roles.ress.length ? db.roles.ress.join(', ') : 'Kosong';
    ctx.reply(
        `👥 <b>DAFTAR ROLE</b>\n━━━━━━━━━━━━━━━━━━\n\n` +
        `💎 Developer: ${devs}\n` +
        `👑 Owner: ${owners}\n` +
        `🔰 TK: ${tks}\n` +
        `🏢 PT: ${pts}\n` +
        `🎯 RESS: ${resss}`,
        { parse_mode: 'HTML' }
    );
});

bot.callbackQuery('owner_devmenu', async (ctx) => {
    await ctx.answerCallbackQuery();
    if (!isDeveloper(ctx.from.id)) return;
    ctx.reply(
        `💎 <b>Developer Menu</b>\n━━━━━━━━━━━━━━━━━━\n\n` +
        `Perintah add role:\n` +
        `/addowner &lt;id&gt; - Tambah Owner\n` +
        `/addtk &lt;id&gt; - Tambah TK\n` +
        `/addpt &lt;id&gt; - Tambah PT\n` +
        `/address &lt;id&gt; - Tambah RESS\n` +
        `/removerole &lt;id&gt; - Hapus role\n` +
        `/listrole - Lihat semua role\n\n` +
        `<i>Cara cari ID user: minta user kirim /start lalu lihat di db.json</i>`,
        { parse_mode: 'HTML' }
    );
});

bot.command('addcredit', async (ctx) => {
    const uid = ctx.from.id;
    const role = getUserRole(uid);
    const allowedRoles = ['developer', 'owner', 'pt', 'tk'];
    if (!role || !allowedRoles.includes(role)) {
        return ctx.reply('❌ Akses ditolak. Hanya <b>Developer</b>, <b>Owner</b>, <b>PT</b>, dan <b>TK</b> yang bisa tambah credit!', { parse_mode: 'HTML' });
    }
    const args = ctx.message.text.split(' ');
    const targetId = args[1];
    const amount = parseInt(args[2]);
    if (!targetId || isNaN(amount) || amount <= 0) {
        return ctx.reply(
            '❌ <b>Format salah!</b>\n\n' +
            'Gunakan: <code>/addcredit ID jumlah</code>\n' +
            'Contoh: <code>/addcredit 123456789 10</code>\n\n' +
            '<i>Tip: Minta user kirim /myid untuk dapat ID mereka</i>',
            { parse_mode: 'HTML' }
        );
    }
    getUser(targetId); // pastikan user ada di DB
    addCredit(targetId, amount);
    const newTotal = getCredit(targetId);
    await ctx.reply(
        `✅ <b>Credit Berhasil Ditambahkan!</b>\n` +
        `━━━━━━━━━━━━━━━━━━\n\n` +
        `🆔 User ID: <code>${targetId}</code>\n` +
        `➕ Ditambahkan: <b>+${amount} credit</b>\n` +
        `🎟 Total sekarang: <b>${newTotal}</b>\n\n` +
        `<i>Oleh: ${getRoleBadge(uid)}</i>`,
        { parse_mode: 'HTML' }
    );
    try {
        await bot.api.sendMessage(targetId,
            `🎉 <b>Credit Kamu Bertambah!</b>\n\n` +
            `➕ <b>+${amount} credit</b> telah ditambahkan\n` +
            `🎟 Total credit sekarang: <b>${newTotal}</b>\n\n` +
            `<i>Selamat menikmati layanan ${config.branding.name}!</i>`,
            { parse_mode: 'HTML' }
        );
    } catch (e) {}
});

// ==================== /myid COMMAND ====================
bot.command('myid', async (ctx) => {
    const uid = ctx.from.id;
    const name = ctx.from.first_name || 'User';
    ctx.reply(
        `🆔 <b>ID Telegram Kamu</b>\n━━━━━━━━━━━━━━━━━━\n\n` +
        `👤 Nama: <b>${name}</b>\n` +
        `🆔 ID: <code>${uid}</code>\n\n` +
        `<i>Copy ID ini dan berikan ke admin untuk penambahan credit/role.</i>`,
        { parse_mode: 'HTML' }
    );
});

// ==================== /broadcast COMMAND ====================
async function doBroadcast(msgText, reportCtx) {
    const ids = Object.keys(db.users);
    let s = 0, f = 0;
    for (const id of ids) {
        try {
            await bot.api.sendMessage(
                Number(id),
                `📢 <b>BROADCAST - ${config.branding.name}</b>\n━━━━━━━━━━━━━━━━━━\n\n` + msgText,
                { parse_mode: 'HTML' }
            );
            s++;
        } catch (e) {
            f++;
        }
        // Delay 300ms antar pesan agar tidak kena rate limit Telegram
        await new Promise(r => setTimeout(r, 300));
    }
    await reportCtx.reply(
        `✅ <b>Broadcast Selesai!</b>\n━━━━━━━━━━━━━━━━━━\n\n` +
        `✅ Terkirim: <b>${s}</b>\n` +
        `❌ Gagal: <b>${f}</b>\n` +
        `👥 Total user: <b>${ids.length}</b>`,
        { parse_mode: 'HTML' }
    );
}

bot.command('broadcast', async (ctx) => {
    const uid = ctx.from.id;
    if (!isDeveloper(uid)) return ctx.reply('❌ Akses ditolak. Hanya <b>Developer</b> yang bisa broadcast!', { parse_mode: 'HTML' });
    const msgText = ctx.message.text.split(' ').slice(1).join(' ').trim();
    if (!msgText) {
        const u = getUser(uid);
        u.step = 'waiting_broadcast_tele';
        saveDB();
        return ctx.reply(
            '📢 <b>Mode Broadcast</b>\n━━━━━━━━━━━━━━━━━━\n\n' +
            'Kirim pesan yang ingin di-broadcast ke semua pengguna bot.\n\n' +
            '<i>Mendukung format HTML: <b>tebal</b>, <i>miring</i>, <code>kode</code></i>\n' +
            'Ketik /cancel untuk membatalkan.',
            { parse_mode: 'HTML' }
        );
    }
    // Broadcast langsung jika ada teks setelah /broadcast
    await ctx.reply('📡 <b>Mengirim broadcast...</b>', { parse_mode: 'HTML' });
    await doBroadcast(msgText, ctx);
});

bot.command('cancel', async (ctx) => {
    const u = getUser(ctx.from.id);
    if (u?.step) { u.step = null; saveDB(); ctx.reply('❌ Proses dibatalkan.'); }
    else ctx.reply('Tidak ada proses aktif.');
});

// ==================== QUEUE SYSTEM ====================
function addToQueue(uid, name, url, type, zipId = null, extra = {}) {
    const job = {
        userId: uid,
        name,
        url,
        type,
        zipId,
        start: Date.now(),
        username: extra.username || null,
        firstName: extra.firstName || null,
        fullName: extra.fullName || null,
        projectFile: extra.projectFile || (name ? `${name}.zip` : "project.zip")
    };
    if (db.building.length < config.server.maxConcurrent) {
        db.building.push(job);
        processBuild(job);
    } else {
        db.queue.push(job);
        bot.api.sendMessage(uid, `📋 Kamu masuk antrian #${db.queue.length}\n⏳ Estimasi: ~${db.queue.length * 2} menit`);
    }
    saveDB();
}

// ==================== GLOBAL ERROR HANDLERS ====================
// Tanpa ini: 1 error bisa bikin bot diam total tanpa restart

bot.catch((err) => {
    const ctx = err.ctx;
    const e = err.error;
    console.error(`[BOT ERROR] Update ${ctx?.update?.update_id}:`, e?.message || e);
    // Coba balas user dengan pesan error
    if (ctx) {
        ctx.reply('⚠️ Terjadi kesalahan internal. Silakan coba lagi.').catch(() => {});
    }
});

process.on('uncaughtException', (err) => {
    console.error('[UNCAUGHT EXCEPTION]', err.message);
    // Jangan exit — biarkan bot tetap jalan
});

process.on('unhandledRejection', (reason) => {
    console.error('[UNHANDLED REJECTION]', reason?.message || reason);
    // Jangan exit — biarkan bot tetap jalan
});

// ==================== START SERVER ====================
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(chalk.green(`🌐 Web berjalan di port: ${PORT}`)));

// Jalankan bot dengan auto-detect local server
(async () => {
    // ── Cek koneksi Telegram cloud API dulu ──
    try {
        const me = await bot.api.getMe();
        console.log(chalk.cyan(`[BOT] Terkoneksi sebagai @${me.username} (ID: ${me.id})`));
    } catch (connErr) {
        console.error(chalk.red('[BOT] ❌ GAGAL KONEKSI KE TELEGRAM:', connErr.message));
        console.error(chalk.red('[BOT] Cek token bot dan koneksi internet!'));
        // Jangan exit — grammY akan retry otomatis saat bot.start()
    }

    // ── Jika local server enabled, cek apakah benar-benar aktif ──
    if (config.localServer?.enabled) {
        try {
            const testRes = await axios.get(
                `${config.localServer.host}/bot${config.bot.token}/getMe`,
                { timeout: 3000 }
            );
            if (testRes.data?.ok) {
                console.log(chalk.yellow(`[BOT] ✅ Local Server aktif: ${config.localServer.host}`));
            } else throw new Error('not ok');
        } catch (_) {
            console.warn(chalk.yellow('[BOT] ⚠️  Local server tidak aktif — menggunakan Telegram cloud API'));
        }
    } else {
        console.log(chalk.cyan('[BOT] Mode: Telegram cloud API (upload max 50MB via multipart)'));
    }

    // ── Cek koneksi ke GitHub API ──
    try {
        await axios.get('https://api.github.com/rate_limit', {
            headers: { 'Authorization': `Bearer ${config.github.token}` },
            timeout: 5000
        });
        console.log(chalk.cyan('[GITHUB] ✅ Koneksi ke GitHub API OK'));
    } catch (ghErr) {
        console.warn(chalk.red(`[GITHUB] ⚠️  Tidak bisa akses GitHub API: ${ghErr.message}`));
        console.warn(chalk.red('[GITHUB] Build APK via GitHub Actions TIDAK akan berfungsi!'));
        console.warn(chalk.red('[GITHUB] Solusi: whitelist api.github.com di panel/firewall server'));
    }

    console.log(chalk.green('┌──────────────────────────────────────────┐'));
    console.log(chalk.green('│   🎮 ASISTEN ELXZ BUILD - BOT AKTIF!   │'));
    console.log(chalk.green('└──────────────────────────────────────────┘'));
    console.log(chalk.cyan(`✅ Bot & Web siap digunakan!`));

    bot.start({
        onStart: (info) => console.log(chalk.cyan(`[BOT] Polling dimulai: @${info.username} ✅`)),
    });
})();
