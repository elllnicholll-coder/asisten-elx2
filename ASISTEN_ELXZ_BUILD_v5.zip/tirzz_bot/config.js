module.exports = {
    bot: {
        // Token dari @BotFather
        token: "8987811979:AAGPzgO_oksKk23UHditrdWo22khlqFtnXU",
        // ID Telegram admin (@userinfobot)
        adminId: "7571009414"
    },

    // ==================== API ID & HASH (my.telegram.org) ====================
    // WAJIB kalau mau pakai Local Bot API (file ZIP > 20MB)
    // Cara dapat:
    // 1. Buka https://my.telegram.org
    // 2. Login nomor HP Telegram
    // 3. API development tools → Create application
    // 4. Salin api_id (angka) dan api_hash (string)
    telegramApi: {
        apiId: "34724046",       // contoh: 12345678
        apiHash: "554248e6b16063ae890fbd42790e63c9"    // contoh: 0123456789abcdef0123456789abcdef
    },

    // Local Bot API Server (file besar sampai 2GB)
    // enabled: true  → harus jalankan setup-local-server.sh dulu + isi apiId/apiHash
    // enabled: false → pakai Telegram cloud (batas ~20MB)
    localServer: {
        enabled: false,
        host: "http://localhost:8081",
        filesDir: "/var/lib/telegram-bot-api",
    },

    github: {
        // Personal Access Token (classic) — centang: repo + workflow
        token: "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",
        owner: "elllnicholll-coder",
        // Repo yang berisi .github/workflows/build.yml
        repo: "elxz-build-builder"
    },

    credit: {
        freePerWeek: 5,
        costPerBuild: 1
    },
    server: {
        maxConcurrent: 3,
        buildTimeout: 600000,
        tempDir: "./temp"
    },
    verification: {
        enabled: true,
        channelUsername: "elxzchannel",
        channelUrl: "https://t.me/elxzchannel",
        channelId: "@elxzchannel"
    },
    logChannel: {
        enabled: true,
        id: "@informasichnlel",
        useLocalImage: true,
        developerName: "elx notdev",
        title: "LIVE BUILD MONITOR"
    },
    contact: {
        owner: "t.me/elnicholl",
        support: "@elnicholl",
        ownerUrl: "https://t.me/elnicholl",
        channelUrl: "https://t.me/elxzchannel",
    },
    branding: {
        name: "ASISTEN ELXZ BUILD",
        botName: "ASISTEN ELXZ BUILD",
        desc: "🤖 ASISTEN ELXZ BUILD v5.0.0\nAutomated Flutter Cloud Compiler & Utility System"
    },
    images: {
        folder: "./images",
        botlogo: "botlogo.jpg",
        monitorlog: "monitorlog.jpg"
    },
    audio: {
        enabled: false,
        fileIdOrUrl: "",
        title: "build",
        performer: "ELXZ OFFICIAL",
        duration: 55
    }
};
