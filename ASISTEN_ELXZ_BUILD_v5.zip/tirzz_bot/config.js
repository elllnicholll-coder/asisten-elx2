module.exports = {
    bot: {
        // Ganti dengan token bot kamu dari @BotFather
        token: "8987811979:AAGPzgO_oksKk23UHditrdWo22khlqFtnXU",
        // ID Telegram admin (bisa dapat dari @userinfobot)
        adminId: "7571009414"
    },
    // ==================== TELEGRAM LOCAL BOT API SERVER ====================
    localServer: {
        enabled: false,
        host: "http://localhost:8081",
        filesDir: "/var/lib/telegram-bot-api",
    },
    github: {
        token: "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",
        owner: "elllnicholll-coder",
        repo: "elxz-build-builder"
    },
    credit: {
        freePerWeek: 5,
        costPerBuild: 1
    },
    server: { 
        maxConcurrent: 3, 
        buildTimeout: 600000, 
        tempDir: "./temp" 
    },
    verification: {
        enabled: true,
        channelUsername: "informasichnlel",
        channelUrl: "https://t.me/informasichnlel",
        channelId: "@informasichnlel"
    },
    // Channel untuk LIVE BUILD MONITOR
    logChannel: {
        enabled: true,
        id: "@informasichnlel",          // bot harus ADMIN di channel ini
        // Gambar log monitor diambil dari folder images/monitorlog.jpg
        // Cukup taruh file monitorlog.jpg di folder images/
        useLocalImage: true,
        developerName: "elx notdev",   // fallback saja (yang tampil = nama user yang build)
        title: "LIVE BUILD MONITOR"
    },
    contact: {
        owner: "t.me/elnicholl",
        support: "@elnicholl",
        ownerUrl: "https://t.me/elnicholl",
        channelUrl: "https://t.me/elxzchannel",
    },
    branding: {
        name: "ASISTEN ELXZ BUILD",
        botName: "ASISTEN ELXZ BUILD",
        desc: "🤖 ASISTEN ELXZ BUILD v5.0.0\nAutomated Flutter Cloud Compiler & Utility System"
    },
    // Semua gambar fitur & logo diambil dari folder images/
    // Cukup taruh file berikut di folder images/ :
    //   botlogo.jpg      → dipakai SEMUA tombol fitur
    //   monitorlog.jpg   → dipakai LIVE BUILD MONITOR
    //   banner.png / banner.mp4 sudah ada di root (welcome)
    images: {
        folder: "./images",
        botlogo: "botlogo.jpg",       // gambar default semua fitur
        monitorlog: "monitorlog.jpg"  // gambar log monitor
    },
    audio: {
        enabled: false,
        fileIdOrUrl: "",
        title: "build",
        performer: "ELXZ OFFICIAL",
        duration: 55
    }
};
