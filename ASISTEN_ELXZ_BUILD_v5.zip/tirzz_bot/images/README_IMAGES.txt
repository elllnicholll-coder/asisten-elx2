========================================
  FOLDER IMAGES - TARUH GAMBAR DI SINI
========================================

1. botlogo.jpg
   → Dipakai SEMUA tombol fitur (Chat AI, Recolour, Rename, dll)
   → Format: JPG / PNG / WEBP (disarankan JPG, max ~5MB)

2. monitorlog.jpg
   → Dipakai LIVE BUILD MONITOR di channel log
   → Format: JPG / PNG / WEBP

Cara pakai:
- Tinggal copy/paste/rename gambar kamu jadi:
    botlogo.jpg
    monitorlog.jpg
- Simpan di folder ini (images/)
- Restart bot → otomatis kepakai

Kalau file belum ada, bot tetap jalan (mode teks saja, tidak error).
