# 🤖 ASISTEN ELXZ BUILD v5.0.0

> **Baca dulu:** `tutorial run.txt` (cara setup, run, dan upload repo)  
> **Gambar:** taruh `botlogo.jpg` + `monitorlog.jpg` di folder `images/`

---

# 🤖 ASISTEN ELXZ BUILD v5.0.0

Automated Flutter Cloud Compiler & Utility System  
Bot Telegram untuk build APK dari project Flutter / Web / Android Studio ZIP, plus banyak utility (rename, recolour, AI rombak, dll).

---

## ✨ Fitur Utama

- 🚀 **Mulai Build APK** — Upload ZIP project Flutter → build via Local / GitHub Actions
- 🌐 **Web to APK** — Convert URL / WebView jadi APK
- 🤖 **Chat AI — Rombak Project** — Instruksi bahasa biasa, AI apply perubahan
- 🎨 Recolour / Multi Recolour
- 🆔 Rename Package ID, Nama APK, Domain, Aset
- 🧹 Bersihkan ZIP (hapus junk/build folder)
- 📊 Antrian Build + Statistik
- 💳 Sistem Credit + Referral
- 📢 **Log Build ke Channel** — Setiap start / success / failed otomatis post ke channel log dengan tombol **🚀 Mau Build Juga?**
- Tombol berwarna lengkap sesuai UI ELXZ

---

## 📋 Persyaratan

- Node.js **≥ 18**
- Akun Telegram + Bot Token dari [@BotFather](https://t.me/BotFather)
- (Opsional) VPS dengan Flutter SDK + Android SDK untuk local build
- (Opsional) GitHub repo + Personal Access Token (scope: `repo` + `workflow`) untuk build via Actions
- Channel Telegram (bot harus **admin**) untuk log build & wajib join

---

## 🚀 Cara Install & Run

### 1. Clone / Upload project

```bash
git clone https://github.com/YOUR_USERNAME/asisten-elxz-build.git
cd asisten-elxz-build
```

Atau extract ZIP ini, lalu:

```bash
cd asisten-elxz-build   # atau nama folder hasil extract
npm install
```

### 2. Edit konfigurasi

Buka `config.js` dan isi semua yang bertanda `YOUR_...`:

```js
bot: {
    token: "123456:ABC-DEF...",          // dari @BotFather
    adminId: "123456789"                 // ID kamu (dari @userinfobot)
},
github: {
    token: "ghp_xxxxxxxx",               // GitHub PAT
    owner: "username_github_kamu",
    repo: "elxz-build-builder"        // nama repo workflow build
},
verification: {
    channelUsername: "channelkamu",
    channelUrl: "https://t.me/channelkamu",
    channelId: "@channelkamu"
},
logChannel: {
    enabled: true,
    id: "@channel_log_build"             // channel khusus log (bot harus admin)
},
contact: {
    owner: "t.me/usernamekamu",
    support: "@usernamekamu",
    ownerUrl: "https://t.me/usernamekamu",
    channelUrl: "https://t.me/channelkamu"
}
```

### 3. Jalankan bot

```bash
npm start
# atau
node index.js
```

Bot akan online. Coba `/start` di Telegram.

### 4. (Opsional) Local Telegram Bot API (file besar >20MB)

Kalau mau support ZIP/APK sampai 2GB:

```bash
# di VPS root
bash setup-local-server.sh
# lalu di config.js set localServer.enabled = true
```

---

## 🐙 Setup ke GitHub (untuk build otomatis)

1. Buat repo baru di GitHub, misal: `elxz-build-builder`
2. Buat file `.github/workflows/build.yml` di repo tersebut (contoh workflow Flutter release):

```yaml
name: Build Flutter APK
on:
  workflow_dispatch:
    inputs:
      app_name:
        description: 'App name'
        required: true
      zip_url:
        description: 'URL ZIP project'
        required: false
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: subosito/flutter-action@v2
        with:
          flutter-version: '3.24.0'
      - name: Download & extract ZIP
        run: |
          # logic download zip_url + unzip di sini
          echo "Extract project..."
      - name: Build APK
        run: |
          flutter pub get
          flutter build apk --release
      - uses: actions/upload-artifact@v4
        with:
          name: release-apk
          path: build/app/outputs/flutter-apk/*.apk
```

3. Generate **Personal Access Token** (classic) di GitHub → Settings → Developer settings → Personal access tokens  
   Centang: `repo`, `workflow`
4. Masukkan token + owner + repo ke `config.js`
5. Bot akan trigger workflow saat user upload ZIP Flutter.

> Catatan: Workflow di atas contoh. Sesuaikan dengan logic download ZIP dari Telegram file URL yang dikirim bot.

---

## 📢 Setup LIVE BUILD MONITOR (Log Channel)

1. Buat channel baru (misal `@elxzbuildlog`)
2. Tambahkan bot sebagai **Administrator** (bisa post message)
3. Isi di `config.js`:
   ```js
   logChannel: {
       enabled: true,
       id: "@elxzbuildlog",
       headerImage: "",                    // opsional: URL gambar header
       developerName: "elx notdev",        // nama yang tampil di log
       title: "LIVE BUILD MONITOR"
   }
   ```
4. Setiap build akan post format seperti ini:

```
📦 LIVE BUILD MONITOR 📦
━━━━━━━━━━━━━━━━━━━━

👤 Developer : elx notdev
🆔 User ID : 7571009414
📦 Project : Nika_projectv1.zip
🔧 Mode : 🚀 Release Build
🏷 Type : Flutter

📊 PROGRES AKTIF:
STATUS → UPLOADING ARTIFACT
DETAIL → Proses kompilasi sukses...

━━━━━━━━━━━━━━━━━━━━
⏱ Waktu Berjalan: 8 Menit 20 Detik
🤖 Multi-build Server Active — Proses berjalan independen.
```

+ Tombol merah **🚀 Mau Build Juga?, Gas!**

## 🖼 Gambar per Fitur (Opsional)

Di `config.js` → `featureImages` kamu bisa isi URL gambar untuk setiap tombol:

```js
featureImages: {
    menu_chat_ai: "https://i.imgur.com/xxxx.png",
    menu_recolour: "https://...",
    default: "https://..."   // fallback
}
```

Kalau diisi, saat user tekan tombol tersebut bot akan kirim **foto + caption**. Kosongkan string jika hanya ingin teks.

---

## 📁 Struktur Project

```
asisten-elxz-build/
├── index.js              # Core bot
├── config.js             # Semua setting (token, channel, github, dll)
├── package.json
├── setup-local-server.sh # Setup local Bot API (opsional)
├── banner.png / banner.mp4
├── Kenz/                 # Dashboard web (opsional)
└── README.md
```

---

## ⚠️ Catatan Penting

- Ganti **semua** token & ID di `config.js` sebelum run.
- Jangan commit token asli ke public repo.
- Fitur AI Rombak / Recolour / Rename Package dll saat ini dalam mode ready (butuh upload ZIP dulu + integrasi AI/backend tambahan untuk full auto).
- Build penuh membutuhkan either:
  - Flutter + Android SDK di server, **atau**
  - GitHub Actions workflow yang siap.
- Credit system sudah aktif (default 5 free / minggu).

---

## 🆘 Support

Edit `config.contact` sesuai kebutuhan.

Selamat memakai **ASISTEN ELXZ BUILD** 🚀
